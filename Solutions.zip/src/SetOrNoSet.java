import java.util.Scanner;

public class SetOrNoSet {

	static int T;
	static String S;
	static boolean[][][] V;
	static boolean[][][] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();

		for (int t = 1; t <= T; ++t) {
			S = sc.next();
			String r = "No Set";
			V = new boolean[S.length()][S.length()][5];
			D = new boolean[S.length()][S.length()][5];
			if (isSet(0, S.length() - 1)) {
				r = "Set";
			}
			System.out.println("Word #" + t + ": " + r);
		}

	}

	public static boolean isSet(int s, int e) {
		if (V[s][e][0]) {
			return D[s][e][0];
		}
		V[s][e][0] = true;
		if (S.charAt(s) == '{' && S.charAt(e) == '}') {
			return D[s][e][0] = isElementList(s + 1, e - 1);
		}
		return D[s][e][0] = false;
	}

	public static boolean isElementList(int s, int e) {
		if (V[s][e][1]) {
			return D[s][e][1];
		}
		V[s][e][1] = true;
		if (s > e) {
			return D[s][e][1] = true;
		}
		return D[s][e][1] = isList(s, e);
	}

	public static boolean isList(int s, int e) {
		if (V[s][e][2]) {
			return D[s][e][2];
		}
		V[s][e][2] = true;
		if (isElement(s, e)) {
			return D[s][e][2] = true;
		}
		for (int i = s + 1; i <= e; ++i) {
			if (S.charAt(i) == ',') {
				if (isElement(s, i - 1) && isList(i + 1, e))
					return D[s][e][2] = true;
			}
		}
		return D[s][e][2] = false;
	}

	public static boolean isElement(int s, int e) {
		if (V[s][e][3]) {
			return D[s][e][3];
		}
		V[s][e][3] = true;
		if (isAtom(s, e)) {
			return D[s][e][3] = true;
		}
		if (isSet(s, e)) {
			return D[s][e][3] = true;
		}
		return D[s][e][3] = false;
	}

	public static boolean isAtom(int s, int e) {
		if (V[s][e][4]) {
			return D[s][e][4];
		}
		V[s][e][4] = true;
		if (s == e) {
			return D[s][e][4] = true;
		} else {
			return D[s][e][4] = false;
		}
	}
}
