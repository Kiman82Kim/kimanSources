import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class MaxCountNum {
	static int N;
	static int[] A;
	static int[][] D;

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		N = Integer.parseInt(br.readLine());
		A = new int[N];
		D = new int[N][2];

		for (int i = 0; i < N; ++i) {
			A[i] = Integer.parseInt(br.readLine());
		}
		Arrays.sort(A);
		D[0][1] = 1;
		D[0][0] = A[0];
		int k = 0;
		int max = 1;
		int maxNum = A[0];
		for (int i = 1; i < N; ++i) {
			if (A[i] == A[i - 1]) {
				D[k][1] = D[k][1] + 1;
			} else {
				if (max < D[k][1]) {
					max = D[k][1];
					maxNum = D[k][0];
				}
				++k;
				D[k][1] = 1;
				D[k][0] = A[i];
			}
		}
		if (max < D[k][1]) {
			max = D[k][1];
			maxNum = D[k][0];
		}
		System.out.println(maxNum);
	}
}
