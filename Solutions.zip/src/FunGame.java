import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class FunGame {

	static int M;
	static int N;
	static int[][] P;
	static int[][] PS;
	static ArrayList<ArrayList<Integer>> G;
	static int setCnt;
	static int[] D;

	static int[] Gx = { 1, 0, -1, 0 };
	static int[] Gy = { 0, -1, 0, 1 };

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		M = sc.nextInt();
		N = sc.nextInt();
		P = new int[M][N];
		PS = new int[M][N];
		G = new ArrayList<ArrayList<Integer>>();
		setCnt = 0;

		for (int m = 0; m < M; ++m) {
			for (int n = 0; n < N; ++n) {
				P[m][n] = sc.nextInt();
			}
		}
		int setNum = 10;
		for (int i = 0; i < M; ++i) {
			for (int j = 0; j < N; ++j) {
				if (P[i][j] < 10) {
					makeSet(j, i, P[i][j], ++setNum);
				}
			}
		}
		setCnt = setNum % 10;
		D = new int[setCnt];

		for (int i = 0; i < M; ++i) {
			for (int j = 0; j < N; ++j) {
				P[i][j] = P[i][j] % 10 - 1;
			}
		}
		for (int i = 0; i < setCnt; ++i) {
			ArrayList<Integer> temp = new ArrayList<Integer>();
			G.add(temp);
		}
		makeGraph();
		//		printP();
		int min = Integer.MAX_VALUE;
		for (int s = 0; s < setCnt; ++s) {
			min = Math.min(bfs(s), min);
		}
		System.out.println(min);
	}

	public static void makeGraph() {
		for (int y = 0; y < M; ++y) {
			for (int x = 0; x < N; ++x) {
				int setNum = P[y][x];

				for (int a = 0; a < 4; ++a) {
					int newY = y + Gy[a];
					int newX = x + Gx[a];
					if (newY >= 0 && newY < M && newX >= 0 && newX < N) {
						if (P[newY][newX] != setNum) {
							if (!G.get(setNum).contains(P[newY][newX])) {
								G.get(setNum).add(P[newY][newX]);
							}
						}
					}
				}
			}
		}

	}

	public static void makeSet(int x, int y, int color, int setNum) {
		P[y][x] = setNum;
		for (int a = 0; a < 4; ++a) {
			int newY = y + Gy[a];
			int newX = x + Gx[a];
			if (newY >= 0 && newY < M && newX >= 0 && newX < N) {
				if (P[newY][newX] == color) {
					makeSet(newX, newY, color, setNum);
				}
			}
		}
	}

	public static int bfs(int s) {
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(s);

		for (int i = 0; i < setCnt; ++i) {
			D[i] = Integer.MAX_VALUE;
		}
		D[s] = 0;
		while (!q.isEmpty()) {
			int v = q.poll();
			for (int next : G.get(v)) {
				if (D[next] == Integer.MAX_VALUE) {
					D[next] = D[v] + 1;
					q.add(next);
				}
			}
		}
		int max = 0;
		for (int i = 0; i < setCnt; ++i) {
			max = Math.max(max, D[i]);
		}
		return max;
	}

	/*
	0 0 1 2 3 3 
	0 1 1 2 2 2 
	0 0 1 2 2 2 
	1 1 1 1 1 1 
	4 4 4 1 5 5 
	 */
	public static void printP() {
		System.out.println();
		for (int i = 0; i < M; ++i) {
			for (int j = 0; j < N; ++j) {
				System.out.print(P[i][j] + " ");
			}
			System.out.println();
		}
	}
}
