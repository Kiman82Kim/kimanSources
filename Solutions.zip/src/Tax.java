import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Tax {

	public static int N;
	public static int K;
	public static int[] M;
	public static long[] D;
	public static long[] S;

	// i ������ �� �� ��
	// �ٸ� �迭 �ϳ����� �� �迭�� �� �迭�� ��ģ��. k ��.
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);

		N = Integer.parseInt(st.nextToken());
		K = Integer.parseInt(st.nextToken());

		M = new int[N];
		D = new long[N];
		S = new long[K];
		str = br.readLine().trim();
		st = new StringTokenizer(str);

		for (int n = 0; n < N; ++n) {
			int num = Integer.parseInt(st.nextToken());
			insert(num, n);
			merge();
		}
		System.out.println(S[0]);
	}

	public static void insert(int num, int n) {
		D[n] = num;
		for (int i = 0; i < n; ++i) {
			if (D[n] > D[n - 1]) {
				long temp = D[n];
				D[n] = D[n - 1];
				D[n - 1] = temp;
			}
		}
	}

	public static void merge() {
		int s = 0;
		int d = 0;
		long[] newS = new long[K];
		for (int i = 0; i < K; ++i) {
			if (D[d] > S[s] || d < N) {
				newS[i] = D[d];
				++d;
			} else {
				newS[i] = S[s];
				++s;
			}
		}
		S = newS;
	}
}
