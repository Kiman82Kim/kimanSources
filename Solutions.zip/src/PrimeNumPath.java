import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class PrimeNumPath {

	static int T;
	static int S;
	static int E;
	static int[] AllPrime;
	static int[] Prime;
	static int[] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AllPrime = new int[10000];
		Prime = new int[10000];
		makePrimeSet();

		Scanner sc = new Scanner(System.in);
		T = sc.nextInt();
		for (int t = 0; t < T; ++t) {
			S = sc.nextInt();
			E = sc.nextInt();
			D = new int[10000];
			for (int i = 0; i < 10000; ++i) {
				D[i] = Integer.MAX_VALUE;
			}
			findPrimePath();
			System.out.println(D[E]);
		}
	}

	public static void makePrimeSet() {
		for (int a = 2; a * a <= 9999; ++a) {
			if (AllPrime[a] == 0) {
				for (int b = a * 2; b <= 9999; b += a) {
					AllPrime[b] = 1;
				}
			}
		}
		int k = 0;
		for (int i = 1000; i <= 9999; ++i) {
			if (AllPrime[i] == 0) {
				Prime[k] = i;
				++k;
			}
		}
	}

	public static void findPrimePath() {
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(S);
		D[S] = 0;

		while (!q.isEmpty()) {
			int v = q.poll();
			for (int b = 1; b < 10000; b *= 10) {
				for (int d = 0; d < 10; ++d) {
					if (b == 1000 && d == 0) {
						continue;
					}
					int next = (v / b / 10) * b * 10 + v % b + b * d;
					if (AllPrime[next] == 0 && D[next] == Integer.MAX_VALUE) {
						D[next] = D[v] + 1;
						q.add(next);
					}
				}
			}
		}
	}
}
