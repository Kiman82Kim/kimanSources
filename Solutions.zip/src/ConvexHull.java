import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class ConvexHull {
	static int N;
	static int[][] XY;
	static int[] Y;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());
		//		Random r = new Random();
		//		N = r.nextInt(100000);
		XY = new int[N][2];
		//		System.out.println(N);
		for (int n = 0; n < N; ++n) {
			//			XY[n][0] = r.nextInt(80000) - 40000;
			//			XY[n][1] = r.nextInt(80000) - 40000;
			StringTokenizer st = new StringTokenizer(br.readLine().trim());
			XY[n][0] = Integer.parseInt(st.nextToken());
			XY[n][1] = Integer.parseInt(st.nextToken());
		}
		int xDiff = XY[0][0];
		int yDiff = XY[0][1];
		for (int i = 1; i < N; ++i) {
			XY[i][0] = XY[i][0] - xDiff;
			XY[i][1] = XY[i][1] - yDiff;
		}
		XY[0][0] = 0;
		XY[0][1] = 0;
		Arrays.sort(XY, 1, N, new Comparator<int[]>() {
			public int compare(int[] a, int[] b) {
				// TODO Auto-generated method stub
				//				if (a[0] == b[0] && a[1] == b[1]) {
				//					return 0;
				//				}
				int c = ccw(0, 0, a[0], a[1], b[0], b[1]);
				if (c < 0) {
					return -1;
				}
				if (c > 0) {
					return 1;
				}
				int a1 = Math.abs(a[0]) + Math.abs(a[1]);
				int a2 = Math.abs(b[0]) + Math.abs(b[1]);
				return a1 - a2;
			}
		});
		ArrayList<Integer> stk = new ArrayList<>();
		stk.add(0);
		for (int i = 1; i < N; i++) {
			int ax = 0;
			int ay = 0;
			int bx = 0;
			int by = 0;
			int cx = 0;
			int cy = 0;
			if (stk.size() > 1) {
				ax = XY[stk.get(stk.size() - 2)][0];
				ay = XY[stk.get(stk.size() - 2)][1];
				bx = XY[stk.get(stk.size() - 1)][0];
				by = XY[stk.get(stk.size() - 1)][1];
				cx = XY[i][0];
				cy = XY[i][1];
			}
			while (stk.size() > 1 && ccw(ax, ay, bx, by, cx, cy) <= 0) {
				stk.remove(stk.size() - 1);
				if (stk.size() > 1) {
					ax = XY[stk.get(stk.size() - 2)][0];
					ay = XY[stk.get(stk.size() - 2)][1];
					bx = XY[stk.get(stk.size() - 1)][0];
					by = XY[stk.get(stk.size() - 1)][1];
					cx = XY[i][0];
					cy = XY[i][1];
				}
			}
			stk.add(i);
		}
		System.out.println(stk.size());

	}

/*
4
3 3
2 1
1 3
4 2

5
3 3
2 1
1 3
4 2
-1 -1

6
2 2
-2 3
1 3
-1 -1
2 -1
0 2

4
1 1
-1 1
-1 -1
1 -1

4
-40000 -40000
40000 40000
-40000 40000
40000 -40000

 */
	public static int ccw(int x1, int y1, int x2, int y2, int x3, int y3) {

		long c = (long) (x2 - x1) * (y3 - y1) - (long) (x3 - x1) * (y2 - y1);
		if (c < 0) {
			return -1;
		} else if (c > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	// ccw(a,b,c)
	// ccw(a,b,c) �ǹ� : ab ���п��� c �� ���� �ٶ� ��, �ݽð� �����̸� ���.
	//(x_2 - x_1)(y_3-y_1) - (y_2-y_1)(x_3-x_1)
	//|((x2-x1)(y3-y1) - (x3-x1)(y2-y1))|
	// ���� �������� ����(���� ������ ���� ª���� ����) ������ ���� ������ ���� ccw �̿���.
	// ���� stack ���� �ΰ��� �̾� ccw ����. 
	// ccw ����̸� stack�� ����. �����̸� ������ pop. �׸��� �������� �ٽ�.

}
