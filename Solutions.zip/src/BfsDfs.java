import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.StringTokenizer;

public class BfsDfs {

	static int V;
	static int E;
	static int S;
	static PriorityQueue<Integer>[] P;
	static PriorityQueue<Integer>[] CP;
	static int[][] D;
	static boolean[] visit;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		V = Integer.parseInt(st.nextToken());
		E = Integer.parseInt(st.nextToken());
		S = Integer.parseInt(st.nextToken());

		P = new PriorityQueue[V + 1];
		CP = new PriorityQueue[V + 1];
		for (int p = 0; p <= V; ++p) {
			P[p] = new PriorityQueue();
			CP[p] = new PriorityQueue();
		}
		D = new int[2][V + 1];
		for (int e = 0; e < E; ++e) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int x = Integer.parseInt(st.nextToken());
			int y = Integer.parseInt(st.nextToken());
			P[x].add(y);
			P[y].add(x);
			CP[x].add(y);
			CP[y].add(x);
		}
		visit = new boolean[V + 1];
		D[0][0] = S;
		visit[S] = true;
		dd = 0;
		dfs(S);
		visit = new boolean[V + 1];
		bfs();
		for (int i = 0; i < V; ++i) {
			if (i == 0) {
				bw.write("" + D[0][i]);
			} else {
				bw.append(" " + D[0][i]);
			}
		}
		bw.append("\n");
		for (int i = 0; i < V; ++i) {
			if (i == 0) {
				bw.append("" + D[1][i]);
			} else {
				bw.append(" " + D[1][i]);
			}
		}
		bw.write("\n");
		bw.flush();
		bw.close();
	}

/*
4 4 1
1 2
1 3
2 3
2 4

4 4 1
1 2
1 3
4 3
2 4

5 9 2
1 2
1 3
1 4
1 5
2 4
2 5
3 4
3 5
4 5

 */
	public static void bfs() {
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(S);
		visit[S] = true;
		int d = 0;
		while (!q.isEmpty()) {
			int s = q.poll();

			D[1][d] = s;
			++d;
			while (!P[s].isEmpty()) {
				int next = P[s].poll();
				if (visit[next]) {
					continue;
				}
				visit[next] = true;
				q.add(next);
			}
		}
	}

	static int dd = 0;

	public static void dfs(int s) {
		if (dd > V) {
			return;
		}
		visit[s] = true;
		while (!CP[s].isEmpty()) {
			int next = CP[s].poll();
			if (visit[next]) {
				continue;
			}

			D[0][++dd] = next;
			dfs(next);
		}
	}
}
