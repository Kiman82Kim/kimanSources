import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class Warp2 {
	static int N;
	static int M;
	static int[] D;
	static ArrayList<Integer>[] con, conv;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());

		con = new ArrayList[N + 1];
		conv = new ArrayList[N + 1];
		D = new int[N + 1];
		for (int i = 1; i <= N; i++) {
			con[i] = new ArrayList<>();
			conv[i] = new ArrayList<>();
			D[i] = Integer.MAX_VALUE;
		}

		PriorityQueue<int[]> que = new PriorityQueue<>(10, new Comparator<int[]>() {
			public int compare(int[] a, int[] b) {
				return a[0] - b[0];
			}
		});
		for (int m = 0; m < M; ++m) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			int cost = Integer.parseInt(st.nextToken());
			con[from].add(to);
			conv[from].add(cost);
		}

		D[1] = 0;
		que.add(new int[] { 0, 1 });
		while (!que.isEmpty()) {
			int q = que.peek()[1], d = que.peek()[0];
			que.poll();
			if (D[q] != d)
				continue;
			for (int i = 0; i < con[q].size(); i++) {
				int t = con[q].get(i), v = conv[q].get(i);
				if (D[t] > D[q] + v) {
					D[t] = D[q] + v;
					que.add(new int[] { (int) D[t], t });
				}
			}
		}
		System.out.println((D[N] < Integer.MAX_VALUE ? D[N] : -1));
	}

/*
4 10
1 4 10
1 2 1
2 1 2
1 3 1
3 1 2
2 4 2
4 2 2
3 4 1
4 3 1
4 1 1
 */
}
