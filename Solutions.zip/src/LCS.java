import java.util.Scanner;

public class LCS {

	static String str1;
	static String str2;
	static int[][] D;
	static int[][] S;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		str1 = sc.next();
		str2 = sc.next();
		D = new int[str1.length() + 1][str2.length() + 1];
		S = new int[str1.length() + 1][str2.length() + 1];
		for (int i = 1; i <= str1.length(); ++i) {
			for (int j = 1; j <= str2.length(); ++j) {
				if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
					D[i][j] = D[i - 1][j - 1] + 1;
					S[i][j] = 3;
				}
				if (D[i - 1][j] >= D[i][j]) {
					S[i][j] = 2;
					D[i][j] = D[i - 1][j];
				}
				if (D[i][j - 1] >= D[i][j]) {
					S[i][j] = 1;
					D[i][j] = D[i][j - 1];
				}
				// D[i][j] = max(D[i][j], D[i - 1][j]);
				// D[i][j] = max(D[i][j], D[i][j - 1]);
			}
		}
		int i = str1.length();
		int j = str2.length();
		String ret = new String();

		while (i > 0 && j > 0) {
			if (S[i][j] == 3) {
				// System.out.print(str1.charAt(i - 1));
				ret += str1.charAt(i - 1);
				--i;
				--j;
			} else if (S[i][j] == 2) {
				--i;
			} else {
				--j;
			}
		}
		for (int k = ret.length() - 1; k >= 0; --k) {
			System.out.print(ret.charAt(k));
		}
		System.out.println();
		// System.out.println(D[str1.length()][str2.length()]);
	}

	public static int max(int a, int b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
	}
}
