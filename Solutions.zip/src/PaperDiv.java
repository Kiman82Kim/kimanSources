import java.util.Scanner;

public class PaperDiv {

	static int N;
	static int[][] P;
	static int W;
	static int B;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		P = new int[N][N];
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				P[i][j] = sc.nextInt();
			}
		}

		div(0, 0, N - 1, N - 1);
		System.out.println(W);
		System.out.println(B);
	}

	public static void div(int fx, int fy, int tx, int ty) {
		int color = P[fy][fx];
		for (int i = fy; i <= ty; ++i) {
			for (int j = fx; j <= tx; ++j) {
				if (color != P[i][j]) {
					div(fx, fy, (fx + tx) / 2, (fy + ty) / 2);
					div((fx + tx) / 2 + 1, (fy + ty) / 2 + 1, tx, ty);
					div(fx, (fy + ty) / 2 + 1, (fx + tx) / 2, ty);
					div((fx + tx) / 2 + 1, fy, tx, (fy + ty) / 2);
					return;
				}
			}
		}
		if (color == 0) {
			++W;
		} else {
			++B;
		}
	}
}
