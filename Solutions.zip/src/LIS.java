import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class LIS {

	static int N;
	static int[] A;
	static int[] D;
	static int Cnt;
	static int LAST;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());

		A = new int[N];
		D = new int[N + 1];
		LAST = -1;
		for (int i = 0; i <= N; ++i) {
			D[i] = Integer.MAX_VALUE;
		}
		Cnt = 0;
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		for (int i = 0; i < N; ++i) {
			A[i] = Integer.parseInt(st.nextToken());
			if (i == 0) {
				D[0] = A[i];
				++Cnt;
			} else {
				int idx = bi(A[i]);
				if (D[idx] == Integer.MAX_VALUE) {
					++Cnt;
				}
				D[idx] = A[i];
			}
		}
		// DP (n^2)
		// D[i] = max(D[j]+1), j<i, A(j)<A(i)
		// indexed tree �ε� Ǯ�� ���� nlogn
		// D[i] = ���̰� i�� IS�� ������ ���Ұ� ���� ���� is�� ������ ���� ��. is : �����κм���. D ���� ���� binary search�� ã�´�.

		System.out.println(Cnt);
	}

	public static int bi(int num) {
		int s = 0;
		int e = D.length - 1;
		int mid = (s + e) / 2;
		while (s <= e) {
			if (e - s <= 3) {
				for (int i = s; i <= e; ++i) {
					if (D[i] >= num) {
						return i;
					}
				}
			}
			if (D[mid] == num) {
				return mid;
			}
			if (D[mid] > num) {
				if (D[mid - 1] < num && D[mid] != Integer.MAX_VALUE) {
					return mid;
				}
				e = mid - 1;
			} else if (D[mid] < num) {
				if (D[mid + 1] >= num) {
					return mid + 1;
				}
				s = mid + 1;
			}
			mid = (s + e) / 2;
		}
		return -1;
	}

}
/*
12
9 67 88 74 44 3 37 87 52 95 39 60

5
94 82 48 60 69 

9
15 27 42 23 48 77 97 48 47 
 */
