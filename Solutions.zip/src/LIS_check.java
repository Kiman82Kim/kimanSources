import java.io.IOException;
import java.util.Random;

public class LIS_check {

	static int N;
	static int[] A;
	static int[] D;
	static int Cnt;
	static int LAST;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//		N = Integer.parseInt(br.readLine().trim());
		Random r = new Random();
		N = r.nextInt(2000);

		for (int rr = 0; rr < 100000; ++rr) {
			LAST = -1;
			Cnt = 0;
			A = new int[N];
			D = new int[N + 1];
			for (int i = 0; i <= N; ++i) {
				D[i] = Integer.MAX_VALUE;
			}
			//		String str = br.readLine().trim();
			//		StringTokenizer st = new StringTokenizer(str);
			for (int i = 0; i < N; ++i) {
				//			A[i] = Integer.parseInt(st.nextToken());
				A[i] = Math.abs(r.nextInt(10000)) + 1;
				if (i == 0) {
					D[0] = A[i];
					++Cnt;
				} else {
					int idx = bi(A[i]);
					if (D[idx] == Integer.MAX_VALUE) {
						++Cnt;
					}
					D[idx] = A[i];
				}
				DP(A[i]);
			}
			// DP (n^2)
			// D[i] = max(D[j]+1), j<i, A(j)<A(i)
			// indexed tree �ε� Ǯ�� ���� nlogn
			// D[i] = ���̰� i�� IS�� ������ ���Ұ� ���� ���� is�� ������ ���� ��. is : �����κм���. D ���� ���� binary search�� ã�´�.

			if (Cnt != LAST + 1) {
				System.out.println("!!!");
				System.out.println(Cnt);
				System.out.println(LAST + 1);
				String s = "";
				for (int i = 0; i < N; ++i) {
					s = s + A[i] + " ";
				}
				System.out.println(s);

			}
		}
		//		System.out.println(Cnt);
	}

	public static int bi(int num) {
		int s = 0;
		int e = D.length - 1;
		int mid = (s + e) / 2;
		while (s <= e) {
			if (e - s <= 3) {
				for (int i = s; i <= e; ++i) {
					if (D[i] >= num) {
						return i;
					}
				}
			}
			if (D[mid] == num) {
				return mid;
			}
			if (D[mid] > num) {
				if (D[mid - 1] < num && D[mid] != Integer.MAX_VALUE) {
					return mid;
				}
				e = mid - 1;
			} else if (D[mid] < num) {
				if (D[mid + 1] >= num) {
					return mid + 1;
				}
				s = mid + 1;
			}
			mid = (s + e) / 2;
		}
		return -1;
	}

	public static int BinarySearch(int value) {
		int first = 0;
		int last = LAST;
		int mid;
		while (first <= last) {
			mid = (first + last) / 2;
			if (mid == 0) {
				if (value <= D[mid]) {
					return mid;
				}

				else {
					if (value < D[mid])
						last = mid - 1;

					else
						first = mid + 1;
				}
			} else {
				if ((value <= D[mid] && value > D[mid - 1])) {
					return mid;
				}

				else {
					if (value < D[mid])
						last = mid - 1;

					else
						first = mid + 1;
				}
			}

			// if target is not existed,
			// not occur reversal of the first and last
		}

		return -1;
	}

	public static void DP(int value) {
		int location = BinarySearch(value);
		if (location == -1) {
			LAST++;
			D[LAST] = value;

		} else {
			D[location] = value;

		}
	}
}
/*
7
1 8 4 12 2 14 6
 */
