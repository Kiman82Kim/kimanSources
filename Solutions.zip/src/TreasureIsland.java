import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class TreasureIsland {

	static class myCompare implements Comparator<Edge> {

		@Override
		public int compare(Edge e1, Edge e2) {
			// TODO Auto-generated method stub
			if (e1.cost > e2.cost) {
				return 1;
			} else {
				return -1;
			}
		}

	}

	static class Edge {
		int from;
		int to;
		int cost;
	}

	static int N;
	static int M;
	static ArrayList<Edge>[] P;
	static int[] D;
	static int[] DB;
	static int endNum;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		endNum = Integer.parseInt(br.readLine().trim());
		P = new ArrayList[N + 1];
		for (int i = 0; i <= N; ++i) {
			P[i] = new ArrayList<Edge>();
		}

		for (int m = 1; m <= M; ++m) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			int cost = Integer.parseInt(st.nextToken());
			Edge e = new Edge();
			e.from = from;
			e.to = to;
			e.cost = cost;
			P[from].add(e);
		}

		D = new int[N + 1];
		for (int i = 0; i <= N; ++i) {
			D[i] = 1234567890;
		}
		DB = new int[N + 1];
		for (int i = 0; i <= N; ++i) {
			DB[i] = 1234567890;
		}
		PriorityQueue<Edge> q = new PriorityQueue<Edge>(M + 1, new myCompare());
		Edge eq = new Edge();
		eq.cost = 0;
		eq.from = 0;
		eq.to = 1;
		q.add(eq);
		D[0] = 0;
		D[1] = 0;
		while (!q.isEmpty()) {
			Edge pe = q.poll();
			int pastNode = pe.from;
			int nodeNum = pe.to;
			int curCost = pe.cost;

			if (D[pastNode] + curCost > D[nodeNum]) {
				continue;
			}
			for (Edge e : P[nodeNum]) {
				if (D[e.from] + e.cost <= D[e.to]) {
					D[e.to] = D[e.from] + e.cost;
					q.add(e);
				}
			}
		}
		if (D[endNum] >= 1234567890) {
			System.out.println("NO");
		} else {
			q = new PriorityQueue<Edge>(M + 1, new myCompare());
			eq = new Edge();
			eq.cost = 0;
			eq.from = 0;
			eq.to = endNum;
			q.add(eq);
			DB[0] = 0;
			DB[endNum] = 0;
			while (!q.isEmpty()) {
				Edge pe = q.poll();
				int pastNode = pe.from;
				int nodeNum = pe.to;
				int curCost = pe.cost;
				if (DB[pastNode] + curCost > DB[nodeNum]) {
					continue;
				}
				for (Edge e : P[nodeNum]) {
					if (DB[e.from] + e.cost <= DB[e.to]) {
						DB[e.to] = DB[e.from] + e.cost;
						q.add(e);
					}
				}
			}
			if (DB[1] >= 1234567890) {
				System.out.println("NO");
			} else {
				System.out.println("YES");
				System.out.println(D[endNum] + DB[1]);
			}
		}
	}
}
/*
5 7
5
1 2 2
3 1 5
1 3 5
2 4 6
4 5 1
5 3 1
3 5 100

4 5
3
1 2 2
2 4 6
4 3 2
1 3 20
3 1 1

3 6
3
1 2 2
2 1 1
2 3 3
3 2 1
3 1 10
1 3 6


3 4
3
1 2 2
2 1 1
2 3 3
1 3 10

2 2
2
1 2 1
2 1 10
*/