import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Picnic {
	static int K;
	static int N;
	static int M;
	static int[] S;
	static ArrayList<Integer>[] P;
	static int[] CN;
	static boolean[] visit;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		K = sc.nextInt();
		N = sc.nextInt();
		M = sc.nextInt();
		CN = new int[N + 1];
		S = new int[K + 1];

		for (int k = 1; k <= K; ++k) {
			S[k] = sc.nextInt();
		}
		P = new ArrayList[N + 1];
		for (int i = 0; i <= N; ++i) {
			P[i] = new ArrayList<Integer>();
		}
		for (int m = 1; m <= M; ++m) {
			int from = sc.nextInt();
			int to = sc.nextInt();
			P[from].add(to);
		}

		Queue<Integer> q = new LinkedList<Integer>();
		int sum = 0;
		for (int k = 1; k <= K; ++k) {
			visit = new boolean[N + 1];
			int s = S[k];
			q.add(s);
			while (!q.isEmpty()) {
				int now = q.poll();
				if (visit[now]) {
					continue;
				}
				++CN[now];
				visit[now] = true;
				if (CN[now] == K) {
					++sum;
				}
				for (int to : P[now]) {
					if (!visit[to]) {
						q.add(to);
					}
				}
			}
		}

		System.out.println(sum);
	}
/*
2 4 6
4
3
1 2
2 1
2 3
3 2
1 3
3 1


 */
}
