import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class CowParty {
	static class Edge {
		int from;
		int to;
		int cost;

		public Edge(int from, int to, int cost) {
			this.from = from;
			this.to = to;
			this.cost = cost;
		}
	}

	static class myCompare implements Comparator<long[]> {

		@Override
		public int compare(long[] arg0, long[] arg1) {
			// TODO Auto-generated method stub
			if (arg0[1] > arg1[1]) {
				return 1;
			} else {
				return -1;
			}
		}

	}

	static int N;
	static int M;
	static int X;
	static long[] GD;
	static long[] BD;
	static ArrayList<Edge>[] P;
	static ArrayList<Edge>[] BP;
	static PriorityQueue<long[]> PQ;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		X = Integer.parseInt(st.nextToken());

		P = new ArrayList[N + 1];
		BP = new ArrayList[N + 1];
		GD = new long[N + 1];
		BD = new long[N + 1];
		PQ = new PriorityQueue(M + 1, new myCompare());
		for (int i = 0; i <= N; ++i) {
			P[i] = new ArrayList<Edge>();
			BP[i] = new ArrayList<Edge>();
			GD[i] = Long.MAX_VALUE;
			BD[i] = Long.MAX_VALUE;
		}
		for (int m = 0; m < M; ++m) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			int cost = Integer.parseInt(st.nextToken());
			P[from].add(new Edge(from, to, cost));
			BP[to].add(new Edge(to, from, cost));
		}

		GD[0] = 0;
		GD[2] = 0;
		PQ.add(new long[] { 2, 0 });
		while (!PQ.isEmpty()) {
			long[] v = PQ.poll();
			int nodeNum = (int) v[0];
			long nodeSumCost = v[1];
			if (GD[nodeNum] != nodeSumCost) {
				continue;
			}
			for (Edge ne : P[nodeNum]) {
				if (GD[nodeNum] + ne.cost <= GD[ne.to]) {
					GD[ne.to] = GD[nodeNum] + ne.cost;
					PQ.add(new long[] { ne.to, GD[ne.to] });
				}
			}
		}

		PQ = new PriorityQueue(M + 1, new myCompare());
		BD[0] = 0;
		BD[2] = 0;
		PQ.add(new long[] { 2, 0 });
		while (!PQ.isEmpty()) {
			long[] v = PQ.poll();
			int nodeNum = (int) v[0];
			long nodeSumCost = v[1];
			if (BD[nodeNum] != nodeSumCost) {
				continue;
			}
			for (Edge ne : BP[nodeNum]) {
				if (BD[nodeNum] + ne.cost <= BD[ne.to]) {
					BD[ne.to] = BD[nodeNum] + ne.cost;
					PQ.add(new long[] { ne.to, BD[ne.to] });
				}
			}
		}
		long max = 0;
		for (int i = 1; i <= N; ++i) {
			max = Math.max(max, GD[i] + BD[i]);
		}
		System.out.println(max);
	}
}
