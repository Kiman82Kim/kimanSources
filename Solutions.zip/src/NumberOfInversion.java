import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class NumberOfInversion {

	static int N;
	static int[] P;
	static int[] T;
	static int[] D;
	static int tLen;
	static int Start;
	static int depth;
	static int maxNum;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());
		D = new int[N + 1];
		StringTokenizer st = new StringTokenizer(br.readLine().trim());
		int max = 0;
		P = new int[N + 1];

		for (int i = 0; i < N; ++i) {
			P[i] = Integer.parseInt(st.nextToken());
			max = Math.max(max, P[i]);
		}
		maxNum = Math.max(max, N);
		initTree();
		for (int i = 0; i < N; ++i) {
			int num = P[i];
			if (num == maxNum) {
				D[i] = 0;
			} else {
				D[i] = treeSum(num + 1, N);
			}
			insertNum(num);
		}
		int sum = 0;
		for (int i = 0; i < N; ++i) {
			sum += D[i];
		}
		System.out.println(sum);
	}
	/*
	8
	8 5 4 7 2 1 3 6
	 */

	public static void initTree() {
		//tree �迭 ũ��
		depth = 1;
		for (int i = 1; (1 << i) < maxNum; ++i) {
			++depth;
		}
		tLen = (1 << depth + 1);

		T = new int[tLen];
		Start = tLen >> 1;
	}

	public static int treeSum(int a, int b) {
		if (a == b) {
			return T[Start + a - 1];
		}
		int sum = 0;
		a = Start + a - 1;
		b = Start + b - 1;
		while (a <= b) {
			if ((a & 1) == 1) {
				sum += T[a];
				++a;
			}
			if ((b & 1) == 0) {
				sum += T[b];
				--b;
			}
			a >>= 1;
			b >>= 1;
		}

		return sum;
	}

	public static void insertNum(int num) {
		int idx = Start + num - 1;

		while (idx >= 1) {
			++T[idx];
			idx /= 2;
		}
	}
}
