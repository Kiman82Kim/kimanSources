import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class AliIsAli {

	static int N;
	static int Q;
	static int[] parent;
	static int[] S;
	static int[] R;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String str = br.readLine().trim();
		N = Integer.parseInt(str);
		str = br.readLine().trim();
		Q = Integer.parseInt(str);

		parent = new int[N + 1];
		S = new int[N + 1];
		R = new int[N + 1];
		for (int i = 0; i <= N; ++i) {
			S[i] = i;
			parent[i] = i;
		}
		for (int q = 0; q < Q; ++q) {
			str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			int type = Integer.parseInt(st.nextToken());
			int a = Integer.parseInt(st.nextToken());
			int b = Integer.parseInt(st.nextToken());
			if (type == 0) {
				merge(a, b);
			} else {
				int u = find(a);
				int v = find(b);
				if (u == v) {
					System.out.println(1);
				} else {
					System.out.println(0);
				}
			}
		}
	}

	public static int find(int e) {
		if (parent[e] == e) {
			return e;
		}
		return parent[e] = find(parent[e]);
	}

	public static void merge(int a, int b) {
		int c = find(a);
		int p = find(b);
		if (c == p) {
			return;
		}
		parent[c] = p;
		if (R[c] == R[p]) {
			++R[p];
		}
		if (R[c] > R[p]) {
			int temp = R[c];
			R[c] = R[p];
			R[p] = temp;
		}
	}
}
