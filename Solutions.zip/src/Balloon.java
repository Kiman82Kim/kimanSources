import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Balloon {

	static int N;
	static int[] H;
	static int[] D;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());
		D = new int[1000000 + 1];
		H = new int[N + 1];

		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		for (int n = 1; n <= N; ++n) {
			H[n] = Integer.parseInt(st.nextToken());
		}
		int p = 1;
		int cnt = 1;
		D[H[1]] = 1;
		while (p <= N) {
			if (D[H[p]] != 0) {
				--D[H[p]];
				++D[H[p] - 1];
				++p;
			} else {
				++cnt;
				++D[H[p]];
			}
		}
		System.out.println(cnt);
	}
}
