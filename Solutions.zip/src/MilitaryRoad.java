import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class MilitaryRoad {

	static class myCompare implements Comparator<Edge> {

		@Override
		public int compare(Edge e1, Edge e2) {
			// TODO Auto-generated method stub
			return e1.cost - e2.cost;
		}

	}

	static class Edge {
		int from;
		int to;
		int cost;
		boolean mark;
		boolean inMst;
	}

	static int K;
	static int M;
	static int N;
	static PriorityQueue<Edge> PQ;
	static int[] Par;
	static int[] rank;
	static ArrayList<Edge> AM;
	static ArrayList<Edge> AK;
	static boolean isUnique;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		// M, K 0 ����.
		M = Integer.parseInt(st.nextToken());
		K = Integer.parseInt(st.nextToken());
		PQ = new PriorityQueue<Edge>(M + K + 1, new myCompare());
		Par = new int[N + 1];
		rank = new int[N + 1];
		AM = new ArrayList<Edge>();
		AK = new ArrayList<Edge>();
		isUnique = true;

		for (int i = 0; i <= N; ++i) {
			Par[i] = i;
		}

		for (int m = 0; m < M; ++m) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			Edge te = new Edge();
			te.from = Integer.parseInt(st.nextToken());
			te.to = Integer.parseInt(st.nextToken());
			te.cost = Integer.parseInt(st.nextToken()) * -1;
			AM.add(te);
		}
		Collections.sort(AM, new myCompare());
		long sum = 0;
		for (int i = 0; i < AM.size(); ++i) {
			Edge me = AM.get(i);
			if (i == 0 || AM.get(i - 1).cost == AM.get(i).cost) {
				for (int j = i; j < AM.size(); ++j) {
					Edge e = AM.get(j);
					if (me.cost != e.cost) {
						break;
					}
					if (find(e.from) != find(e.to)) {
						e.mark = true;
					}
				}
			}
			int v = find(me.from);
			int u = find(me.to);
			if (v == u) {
				// cycle
				sum = sum + (-1 * me.cost);
			} else {
				me.inMst = true;
				merge(me.from, me.to);
			}
		}

		for (int k = 0; k < K; ++k) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			Edge te = new Edge();
			te.from = Integer.parseInt(st.nextToken());
			te.to = Integer.parseInt(st.nextToken());
			te.cost = Integer.parseInt(st.nextToken());
			AK.add(te);
		}
		Collections.sort(AK, new myCompare());
		for (int i = 0; i < AK.size(); ++i) {
			Edge ke = AK.get(i);
			if (i == 0 || AK.get(i - 1).cost == AK.get(i).cost) {
				for (int j = i; j < AK.size(); ++j) {
					Edge e = AK.get(j);
					if (ke.cost != e.cost) {
						break;
					}
					if (find(e.from) != find(e.to)) {
						e.mark = true;
					}
				}
			}
			int v = find(ke.from);
			int u = find(ke.to);
			if (v == u) {
				// cycle
			} else {
				merge(ke.from, ke.to);
				sum = sum + ke.cost;
				ke.inMst = true;
			}
		}
		for (Edge e : AM) {
			if (!e.inMst && e.mark) {
				isUnique = false;
			}
		}
		for (Edge e : AK) {
			if (!e.inMst && e.mark) {
				isUnique = false;
			}
		}
		String unique;
		if (isUnique) {
			unique = "unique";
		} else {
			unique = "not unique";
		}
		System.out.println(sum + " " + unique);
	}

	public static int find(int c) {
		if (c == Par[c]) {
			return c;
		}
		return Par[c] = find(Par[c]);
	}

	public static void merge(int a, int b) {
		int u = find(a);
		int v = find(b);
		if (u == v) {
			return;
		}
		Par[v] = u;
		if (rank[u] == rank[v]) {
			++rank[u];
			Par[v] = u;
		}
		if (rank[v] > rank[u]) {
			int temp = rank[v];
			rank[v] = rank[u];
			rank[u] = temp;
		}
	}
}

/*
3 1 2
1 3 2
2 3 2
1 2 2

5 3 4
1 2 1
1 3 4
2 3 2
2 4 2
3 5 2
3 4 7
4 5 4

3 1 2
1 2 3
1 3 3
2 3 3

7 11 0
1 4 5
3 5 5
4 6 6
1 2 7
2 5 7
2 3 8
5 6 8
2 4 9
5 7 9
6 7 11
4 5 15
*/