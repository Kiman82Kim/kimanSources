import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class SalesPerson {

	static int N;
	static ArrayList<Integer>[] P;
	static int[] Depth;
	static int[][] Par; // Par[i][j] = i�� ������ 2^j ��° �θ�

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());

		P = new ArrayList[N + 1];
		Depth = new int[N + 1];
		Par = new int[N + 1][17];

		for (int i = 0; i <= N; ++i) {
			P[i] = new ArrayList<Integer>();
		}
		for (int i = 0; i < N - 1; ++i) {
			String str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			int x = Integer.parseInt(st.nextToken());
			int y = Integer.parseInt(st.nextToken());
			P[x].add(y);
			P[y].add(x);
		}
		// root = 1;
		Queue<Integer> que = new LinkedList<Integer>();
		boolean[] visit = new boolean[N + 1];
		que.add(1);
		visit[1] = true;
		Depth[1] = 0;
		int maxDepth = 0;
		while (!que.isEmpty()) {
			int from = que.poll();
			for (int to : P[from]) {
				if (!visit[to]) {
					Depth[to] = Depth[from] + 1;
					maxDepth = Math.max(maxDepth, Depth[to]);
					Par[to][0] = from;
					visit[to] = true;
					que.add(to);
				}
			}
		}
		int maxP = 0;
		for (int i = 0; (1 << i) < maxDepth; ++i) {
			++maxP;
		}
		// sparse talbe
		for (int j = 1; j < 17; ++j) {
			for (int i = 1; i <= N; ++i) {
				Par[i][j] = Par[Par[i][j - 1]][j - 1];
			}
		}
		// ��� ���ø� ���ƴٴѴ�.
		long pathLength = 0;
		for (int city = 1; city < N; ++city) {
			int a = city;
			int b = city + 1;

			if (Depth[a] < Depth[b]) {
				int temp = a;
				a = b;
				b = temp;
			}
			int c = Depth[a] - Depth[b];
			for (int i = 0; (1 << i) <= c; ++i) {
				if ((c & (1 << i)) != 0) {
					a = Par[a][i];
				}
			}
			if (a == b) {
				pathLength += c;
				continue;
			}
			for (int p = 16; p >= 0; --p) {
				if (Par[a][p] != Par[b][p]) {
					a = Par[a][p];
					b = Par[b][p];
				}
			}
			int lca = Par[a][0];
			pathLength += Depth[city] + Depth[city + 1] - (2 * Depth[lca]);
		}
		System.out.println(pathLength);
	}
}
/*
8
1 2
2 7
1 6
6 4
6 3
3 5
2 8
 */
