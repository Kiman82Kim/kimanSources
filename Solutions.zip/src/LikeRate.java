import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;
import java.util.StringTokenizer;

public class LikeRate {

	static int N;
	static int[][] XY;

	// �������� ������ �̰� 20% ���� �ִ��� Ȯ���Ѵ�. ccw �� Ȯ��.
	// 300 �� ���� �ϸ� ��.
	// 20 % Ȯ���� 5�� ���ؼ� N�� ������ 20% ������ 20%�̻�.
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int T = Integer.parseInt(br.readLine().trim());
		for (int t = 1; t <= T; ++t) {
			N = Integer.parseInt(br.readLine().trim());
			XY = new int[N][2];
			for (int n = 0; n < N; ++n) {
				StringTokenizer st = new StringTokenizer(br.readLine().trim());
				XY[n][0] = Integer.parseInt(st.nextToken());
				XY[n][1] = Integer.parseInt(st.nextToken());
			}

			Random r = new Random();
			String s = "NO";
			boolean ans = false;
			for (int test = 1; test <= 300; ++test) {
				int[] a = new int[2];
				int idxA = r.nextInt(N);
				int idxB = r.nextInt(N);
				while (idxA == idxB) {
					idxB = r.nextInt(N);
				}
				int cnt = 1;
				for (int i = 0; i < N; ++i) {
					if (i != idxA && i != idxB) {
						if (ccw(XY[idxA][0], XY[idxA][1], XY[idxB][0], XY[idxB][1], XY[i][0], XY[i][1]) == 0) {
							++cnt;
						}
					}
				}
				if (cnt * 5 >= N) {
					s = "YES";
					break;
				}
			}
			System.out.println("#" + t + " " + s);
		}

	}

	public static int ccw(int x1, int y1, int x2, int y2, int x3, int y3) {
		long c = (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
		if (c > 0) {
			return 1;
		}
		if (c < 0) {
			return -1;
		}
		return 0;
	}
	/*
	2
	9
	0 0
	0 1
	0 2
	1 0
	1 1
	1 2
	2 0
	2 1
	2 2
	21
	0 0
	0 1
	3 1
	4 1
	10 2
	11 2
	25 3 
	26 3
	50 4 
	51 4
	100 101
	110 111
	113 111
	114 111
	1110 1112
	1111 21112
	1125 2113 
	1126 2113
	1150 2114 
	1151 2114
	11100 1101
	 */
}
