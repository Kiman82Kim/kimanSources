import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class ClosestDots {

	static int N;
	static int[][] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		D = new int[N][2];
		for (int n = 0; n < N; ++n) {
			D[n][0] = sc.nextInt();
			D[n][1] = sc.nextInt();
		}
		Arrays.sort(D, new Comparator<int[]>() {
			public int compare(int[] a, int[] b) {
				// TODO Auto-generated method stub
				if (a[0] > b[0]) {
					return 1;
				} else if (a[0] < b[0]) {
					return -1;
				}
				return 0;
			}
		});

		int[] p = new int[2];
		long minLen = findClosestDot(0, N - 1);
		System.out.println(minLen);
	}

	public static long findClosestDot(int from, int to) {
		if (to - from <= 0) {
			return Long.MAX_VALUE;
		}
		if (to - from == 1) {
			return dist(from, to);
		}
		long min;
		if (to - from == 2) {
			min = Math.min(dist(from, from + 1), dist(from + 1, to));
			min = Math.min(dist(from, to), min);
			return min;
		}
		int mid = (from + to) / 2;
		long a = findClosestDot(from, mid);
		long b = findClosestDot(mid + 1, to);
		min = Math.min(a, b);

		long midC = dlr(from, to, min);
		return min;
	}

	public static long dist(int from, int to) {
		return (D[to][1] - D[from][1]) * (D[to][1] - D[from][1]) + (D[to][0] - D[from][0]) * (D[to][0] - D[from][0]);
	}

	public static long dlr(int from, int to, long d) {
		int mid = (from + to) / 2;
		int s = (int) (mid - d);
		int e = (int) (mid + d);

		Arrays.sort(D, mid, e, new Comparator<int[]>() {
			public int compare(int[] a, int[] b) {
				// TODO Auto-generated method stub
				if (a[1] > b[1]) {
					return 1;
				} else if (a[1] < b[1]) {
					return -1;
				}
				return 0;
			}
		});

		int m = (s + e) / 2;
		long min = Long.MAX_VALUE;
		for (int i = s; i < e; ++i) {
			for (int j = i + 1; j <= e; ++j) {
				min = Math.min(min, dist(i, j));
			}
		}
		return min;
	}

	//  �ڵ�.
	/*
	static class point {
		int x;
		int y;
	}
	
	static int dist(point p, point q) {
		return (p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y);
	}
	
	static boolean cmpPointX(point p, point q) {
		return p.x < q.x;
	}
	
	static boolean cmpPointY(point p, point q) {
		return p.y < q.y;
	}
	
	int closestPair(point []P, int n) {
	    if (n == 2) return dist(P[0], P[1]);
	    int min;
	    if (n == 3){
	        min= Math.min(dist(P[0], P[1]), dist(P[1], P[2]));
	        min = Math.min(dist(P[2], P[0]), min);
	        return min;
	    }
	    
	    int line = (P[n/2-1].x+P[n/2].x)/2;
	    int d = min(closestPair(P, n/2), closestPair(P[n/2], n-n/2));
	    
	    point Mid[n];
	    int midN = 0;
	    
	    for (int i=0; i<n; i++) {
	        int t = line-P[i].x;
	        if (t*t <= d) Mid[midN++] = P[i];
	    }
	    
	    sort(Mid, Mid+midN, cmpPointY);
	    
	    for (int i=0; i<midN; i++) {
	        for (int j=i+1; j<midN && j<=i+6; j++) {
	            d = Math.min(d, dist(Mid[i], Mid[j]));
	        }
	    }
	    
	    return d;
	}
	*/
}

/*
6
0 0
2 9
10 10
2 2
0 10
10 0
 */
