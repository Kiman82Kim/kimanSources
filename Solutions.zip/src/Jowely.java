import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.StringTokenizer;

public class Jowely {

	static class myCompare implements Comparator<int[]> {

		@Override
		public int compare(int[] arg0, int[] arg1) {
			// TODO Auto-generated method stub
			if (arg0[0] > arg1[0]) {
				return 1;
			} else {
				return -1;
			}
		}
	}

	static int N;
	static int K;
	static int[] BM;
	static int[][] VM;

	static PriorityQueue<Integer> T;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		T = new PriorityQueue<Integer>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		K = Integer.parseInt(st.nextToken());
		//		N = 300;
		//		K = 300;
		VM = new int[N + 1][2];
		BM = new int[K + 1];
		Random r = new Random();

		for (int n = 1; n <= N; ++n) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			VM[n][0] = Integer.parseInt(st.nextToken());
			VM[n][1] = Integer.parseInt(st.nextToken());
			//			VM[n][0] = r.nextInt();
			//			VM[n][1] = r.nextInt();
		}
		for (int k = 1; k <= K; ++k) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			BM[k] = Integer.parseInt(st.nextToken());
			//			BM[k] = r.nextInt();
		}

		Arrays.sort(BM);
		Arrays.sort(VM, new myCompare());

		long sum = 0;
		int idx = 1;
		for (int j = 1; j <= K; ++j) {
			while (idx <= N && BM[j] >= VM[idx][0]) {
				int v = VM[idx][1];
				T.add(-v);
				++idx;
			}
			if (!T.isEmpty()) {
				sum += (long) -T.poll();
			}
		}
		System.out.println(sum);
	}

}
/*
3 2
5 23
2 99
1 65
10
2
 */
