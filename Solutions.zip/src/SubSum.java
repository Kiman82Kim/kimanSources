import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class SubSum {

	public static int N;
	public static int Q;
	public static long[] T;
	public static int AL;
	public static int Depth;
	public static int vStart;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		N = Integer.parseInt(br.readLine().trim());
		Q = Integer.parseInt(br.readLine().trim());

		AL = 1;
		Depth = 0;

		while (AL < N) {
			AL *= 2;
			++Depth;
		}
		AL = (int) Math.pow(2, Depth + 1);
		T = new long[AL];
		// 2^depth ���� depth 0�� ���� ����.

		vStart = (int) Math.pow(2, Depth);
		for (int i = vStart; i < vStart + N; ++i) {
			T[i] = i - vStart + 1;
		}
		initTree(vStart);
		for (int q = 0; q < Q; ++q) {
			String str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			int type = Integer.parseInt(st.nextToken());
			if (type == 0) {
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				changeTree(x, y);
			} else {
				int from = Integer.parseInt(st.nextToken());
				int to = Integer.parseInt(st.nextToken());
				long sum = sumTree(from, to);
				System.out.println(sum);
			}
		}
	}

	public static void initTree(int vStart) {
		int temp = vStart + N - 1;
		temp = temp / 2;
		while (temp > 0) {
			T[temp] = T[temp * 2] + T[temp * 2 + 1];
			--temp;
		}
	}

	public static void changeTree(int x, int y) {
		int idx = x + vStart - 1;
		T[idx] = y;
		while (idx > 0) {
			idx >>= 1;
			if (idx == 0) {
				break;
			}
			T[idx] = T[2 * idx] + T[2 * idx + 1];
		}
	}

	public static long sumTree(int from, int to) {
		long sum = 0;
		from += vStart - 1;
		to += vStart - 1;
		while (from < to) {
			if ((from & 1) == 0) { // left child

			} else { // right child
				sum += (long) T[from];
				++from;
			}
			if ((to & 1) == 0) {
				sum += (long) T[to];
				--to;
			} else {

			}
			from = from >> 1;
			to = to >> 1;
		}
		if (from == to) {
			sum += (long) T[from];
		}
		return sum;
	}
}
