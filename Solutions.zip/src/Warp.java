import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class Warp {

	static class Edge {
		int from;
		int to;
		int cost;
	}

	static class myCompare implements Comparator<long[]> {

		@Override
		public int compare(long[] a, long[] b) {
			// TODO Auto-generated method stub
			if (a[1] > b[1]) {
				return 1;
			} else {
				return -1;
			}
		}

	}

	static int N;
	static int M;
	static ArrayList<Edge>[] P;
	static long[] D;
	static PriorityQueue<long[]> q;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		P = new ArrayList[N + 1];
		D = new long[N + 1];
		for (int i = 0; i <= N; ++i) {
			P[i] = new ArrayList<Edge>();
			D[i] = Long.MAX_VALUE;
		}

		q = new PriorityQueue<long[]>(M, new myCompare());
		for (int m = 0; m < M; ++m) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			int cost = Integer.parseInt(st.nextToken());
			Edge te = new Edge();
			te.from = from;
			te.to = to;
			te.cost = cost;
			P[from].add(te);
		}

		Edge e = new Edge();
		e.from = 0;
		e.to = 1;
		e.cost = 0;

		D[0] = 0;
		D[1] = 0;
		q.add(new long[] { 1, 0 });
		while (!q.isEmpty()) {
			long[] node = q.poll();
			int nodeNum = (int) node[0];
			long nodeSumCost = node[1];

			if (D[nodeNum] != nodeSumCost) {
				continue;
			}
			for (Edge pe : P[nodeNum]) {
				if (D[nodeNum] + pe.cost < D[pe.to]) {
					D[pe.to] = D[nodeNum] + pe.cost;
					q.add(new long[] { pe.to, D[pe.to] });
				}
			}
		}

		if (D[N] == Long.MAX_VALUE) {
			System.out.println(-1);
		} else {
			System.out.println(D[N]);
		}
	}

/*
 * 
4 4
1 2 1
2 3 1
3 4 1
1 4 2

4 10
1 4 10
1 2 1
2 1 2
1 3 1
3 1 2
2 4 2
4 2 2
3 4 1
4 3 1
4 1 1
 */
}
