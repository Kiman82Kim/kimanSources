import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class FarFarTwoCity {

	static int[][] W;
	static int[][] D;
	static int N;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		W = new int[N][N];
		D = new int[N][N];
		for (int i = 0; i < N; ++i) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			for (int j = 0; j < N; ++j) {
				W[i][j] = Integer.parseInt(st.nextToken());
				D[i][j] = W[i][j];
			}
		}
		int max = 0;
		for (int k = 0; k < N; ++k) {
			for (int i = 0; i < N; ++i) {
				for (int j = 0; j < N; ++j) {
					if (D[i][j] > D[i][k] + D[k][j]) {
						D[i][j] = D[i][k] + D[k][j];
					}
				}
			}
		}

		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				max = Math.max(max, D[i][j]);
			}
		}
		System.out.println(max);
	}

}
