import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class Histogram {

	static int N;
	static int[] H;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		for (int t = 0; t < 100000; ++t) {
			String str = br.readLine().trim();
			if (str.equals("0")) {
				return;
			}
			StringTokenizer st = new StringTokenizer(str);
			N = Integer.parseInt(st.nextToken());
			H = new int[N + 2];
			for (int n = 1; n <= N; ++n) {
				H[n] = Integer.parseInt(st.nextToken());
			}
			long sum = maxRact(1, N);
			System.out.println(sum);
		}
	}

/*
7 2 1 4 5 1 3 3
4 1000 1000 1000 1000
0
 */
	public static long maxRact(int from, int to) {
		if (from == to) {
			return H[from];
		}
		long max = 0;
		int mid = (from + to) / 2;
		long lr = maxRact(from, mid);
		long rr = maxRact(mid + 1, to);
		max = Math.max(lr, rr);

		int s = mid;
		int e = mid;
		int w = 1;
		int h = H[mid];
		while (s >= from && e <= to) {
			long mr = (long) w * h;
			max = Math.max(max, mr);
			int lh = 0;
			int rh = 0;
			if (s - 1 != 0) {
				lh = H[s - 1];
			}
			if (e + 1 != N) {
				rh = H[e + 1];
			}
			if (lh > rh) {
				--s;
				h = lh;
			} else {
				++e;
				h = rh;
			}
			++w;
		}
		return max;
	}
}
