import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Test01 {

	static class Link {
		int a;
		int b;
	}

	static class Que {
		int type;
		int k;
		int a;
		int b;
	}

	static int N;
	static int Q;
	static int M;
	static int[] P;
	static int[] rank;
	static Que[] Qarr;
	static Link[] Marr;
	static boolean[] C;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		int T = Integer.parseInt(br.readLine().trim());
		for (int t = 1; t <= T; ++t) {
			String str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			P = new int[N + 1];
			Marr = new Link[M + 1];
			rank = new int[N + 1];
			for (int i = 0; i < N; ++i) {
				P[i + 1] = i + 1;
				rank[i + 1] = 1;
			}
			Marr[0] = new Link();
			for (int m = 1; m <= M; ++m) {
				Marr[m] = new Link();
				Link l = new Link();
				str = br.readLine().trim();
				st = new StringTokenizer(str);
				int a = Integer.parseInt(st.nextToken());
				int b = Integer.parseInt(st.nextToken());
				l.a = a;
				l.b = b;
				Marr[m] = l;
			}

			Q = Integer.parseInt(br.readLine().trim());
			Qarr = new Que[Q + 1];
			C = new boolean[M + 1];

			Qarr[0] = new Que();
			for (int q = 1; q <= Q; ++q) {
				Qarr[q] = new Que();
				Que nq = new Que();
				str = br.readLine().trim();
				st = new StringTokenizer(str);
				int qType = Integer.parseInt(st.nextToken());
				nq.type = qType;
				if (qType == 1) { // cut
					int k = Integer.parseInt(st.nextToken());
					nq.k = k;
					C[k] = true;
				} else { // check
					int a = Integer.parseInt(st.nextToken());
					int b = Integer.parseInt(st.nextToken());
					nq.a = a;
					nq.b = b;
				}
				Qarr[q] = nq;
			}
			for (int i = 1; i <= M; ++i) {
				if (C[i]) {
					continue;
				}
				int a = Marr[i].a;
				int b = Marr[i].b;
				merge(a, b);
			}
			StringBuffer sb = new StringBuffer();
			for (int i = Q; i > 0; --i) {
				if (Qarr[i].type == 1) {
					int k = Qarr[i].k;
					int a = Marr[k].a;
					int b = Marr[k].b;
					merge(a, b);
				} else {
					int a = Qarr[i].a;
					int b = Qarr[i].b;
					int u = find(a);
					int v = find(b);
					if (u == v) {
						//						bw.write("1");
						sb.append("1");
					} else {
						//						bw.write("0");
						sb.append("0");
					}
				}
			}
			sb = sb.reverse();
			bw.write("#" + t + " " + sb.toString() + "\n");
			bw.flush();
		}
		bw.close();
	}

	public static int find(int c) {
		if (P[c] == c) {
			return c;
		}
		int i = c;
		int u = P[i];
		while (i != P[i]) {
			i = P[i];
		}
		int j = P[c];
		while (j != P[j]) {
			P[j] = i;
		}
		return i;
	}

	public static void merge(int a, int b) {
		int u = find(a);
		int v = find(b);

		if (u == v) {
			return;
		}
		P[v] = u;
		if (rank[u] == rank[v]) {
			++rank[u];
		}
		if (rank[v] > rank[u]) {
			int temp;
			temp = rank[v];
			rank[v] = rank[u];
			rank[u] = temp;
		}
	}
}
