import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;

public class DrinkingAppoinments {
	static class Path {
		int d;
		int t;

		public Path(int d, int t) {
			this.d = d;
			this.t = t;
		}
	}

	static int N;
	static Path[] P;
	static long[] D;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		P = new Path[N];
		D = new long[N + 1];

		for (int i = 0; i < N; ++i) {

			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int t = Integer.parseInt(st.nextToken());
			int d = Integer.parseInt(st.nextToken());
			// �Ǽ� ���� ���� ����. compare �� �������� ����.
			P[i] = new Path(d, t);
		}
		Arrays.sort(P, new Comparator<Path>() {
			public int compare(Path a, Path b) {
				if (a.d * b.t < b.d * a.t) {
					return 1;
				}
				if (a.d * b.t > b.d * a.t) {
					return -1;
				}
				return 0;
			}
		});

		long sum = 0;

		for (int i = 1; i <= N; ++i) {
			D[i] = (D[i - 1] + (long) (P[i - 1].t * 2));
			sum += D[i - 1] * (long) P[i - 1].d;
		}
		System.out.println(sum);
	}

}
