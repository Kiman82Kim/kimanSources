import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Climbing {

	static class Position {
		int x;
		int y;

		public Position(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}

	static int N;
	static int[][] M;
	static int[] Gx = { 1, 0, -1, 0 };
	static int[] Gy = { 0, -1, 0, 1 };
	static boolean[][] V;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		M = new int[N][N];

		int small = 1000;
		int big = 0;
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				M[i][j] = sc.nextInt();
				small = Math.min(small, M[i][j]);
				big = Math.max(big, M[i][j]);
			}
		}

		int hMin = 1000;
		int sMin = Math.min(M[0][0], M[N - 1][N - 1]);
		while (big > small) {
			int mid = (small + big) / 2;
			//			boolean possible = dfs(min, max, mid, x, y);
			boolean possible = false;
			for (int i = small; i <= big; ++i) {
				possible = bfs(mid, i);
				if (possible) {
					break;
				}
			}
			if (possible) {
				big = mid;
				hMin = Math.min(hMin, mid);
			} else {
				small = mid + 1;
			}
		}
		System.out.println(hMin);
	}

	public static void initV(int mid, int low) {
		V = new boolean[N][N];
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				if (M[i][j] > mid + low || M[i][j] < low) {
					V[i][j] = true;
				}
			}
		}
	}

	public static boolean bfs(int mid, int checkLow) {
		Queue<Position> q = new LinkedList<Position>();

		initV(mid, checkLow);
		if (V[0][0]) {
			return false;
		}

		q.add(new Position(0, 0));
		while (!q.isEmpty()) {
			Position p = q.poll();

			int y = p.y;
			int x = p.x;
			if (y == N - 1 && x == N - 1) {
				return true;
			}
			for (int d = 0; d < 4; ++d) {
				int newY = Gy[d] + y;
				int newX = Gx[d] + x;
				if (newY >= 0 && newY < N && newX >= 0 && newX < N && !V[newY][newX]) {
					q.add(new Position(newX, newY));
					V[newY][newX] = true;
				}
			}
		}
		return false;
	}

	public static boolean dfs(int min, int max, int crv, int x, int y) {
		int h = M[y][x];
		min = Math.min(h, min);
		max = Math.max(h, max);
		if (max - min > crv) {
			return false;
		}
		V[y][x] = true;
		if (x == N - 1 && y == N - 1) {
			return true;
		}
		boolean r = false;
		for (int d = 0; d < 4; ++d) {
			int newY = Gy[d] + y;
			int newX = Gx[d] + x;
			if (newY >= 0 && newY < N && newX >= 0 && newX < N && !V[newY][newX]) {
				r = dfs(min, max, crv, newX, newY);
				if (r) {
					return r;
				}
			}
		}
		return r;
	}
}
