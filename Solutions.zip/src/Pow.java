import java.util.Scanner;

public class Pow {

	static long A;
	static long M;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		A = sc.nextLong();
		M = sc.nextLong();

		long p = pow(A, M) % 1000000007;
		System.out.println(p);
	}

	// 9223372036854775807 9223372036854775807
	public static long pow(long a, long m) {
		if (m == 0) {
			return 1;
		}
		if ((m & 1) == 1) {
			return pow(a % 1000000007, m - 1) % 1000000007 * a % 1000000007;
		}
		if (m == 2) {
			return (a % 1000000007) * (a % 1000000007) % 1000000007;
		}
		long p1 = pow(a % 1000000007, m / 2) % 1000000007;
		return (p1 % 1000000007) * (p1 % 1000000007) % 1000000007;
	}
}
