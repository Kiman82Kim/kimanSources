import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class WormHole {

	static class Edge {
		int from;
		int to;
		int cost;

		public Edge(int from, int to, int cost) {
			this.from = from;
			this.to = to;
			this.cost = cost;
		}

	}

	static int T;
	static int N;
	static int M;
	static int W;
	static long[] D;
	static ArrayList<Edge> EL;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		T = Integer.parseInt(br.readLine().trim());

		while (T-- > 0) {
			String str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			N = Integer.parseInt(st.nextToken());
			M = Integer.parseInt(st.nextToken());
			W = Integer.parseInt(st.nextToken());

			EL = new ArrayList<Edge>();
			D = new long[N + 1];
			for (int i = 1; i < N + 1; ++i) {
				D[i] = Integer.MAX_VALUE;
			}

			EL.add(new Edge(0, 0, 0));
			for (int m = 0; m < M; ++m) {
				str = br.readLine().trim();
				st = new StringTokenizer(str);
				int s = Integer.parseInt(st.nextToken());
				int e = Integer.parseInt(st.nextToken());
				int c = Integer.parseInt(st.nextToken());
				EL.add(new Edge(s, e, c));
				EL.add(new Edge(e, s, c));
			}
			for (int w = 0; w < W; ++w) {
				str = br.readLine().trim();
				st = new StringTokenizer(str);
				int s = Integer.parseInt(st.nextToken());
				int e = Integer.parseInt(st.nextToken());
				int c = -Integer.parseInt(st.nextToken());
				EL.add(new Edge(s, e, c));
			}

			boolean isEnd = false;
			for (int s = 1; s <= N; ++s) {
				D[s] = 0;
				for (int i = 1; i < N; ++i) {
					for (int j = 1; j < EL.size(); ++j) {
						Edge e = (Edge) EL.get(j);
						if (D[e.from] + e.cost < D[e.to]) {
							D[e.to] = (long) D[e.from] + e.cost;
						}
					}
				}
				for (int j = 1; j < EL.size(); ++j) {
					Edge e = (Edge) EL.get(j);
					if (D[e.from] + e.cost < D[e.to]) {
						bw.write("YES\n");
						isEnd = true;
						break;
					}
				}
				if (isEnd) {
					break;
				}
			}
			if (!isEnd) {
				bw.write("NO\n");
			}
		}
		bw.flush();
		bw.close();
	}

}
/*
1
3 1 3
3 2 1
1 2 3
2 3 4
3 1 8

1
3 3 1
2 3 1
1 2 2
1 3 4
3 1 3
*/
