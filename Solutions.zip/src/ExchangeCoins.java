import java.util.Scanner;

/*
4
2 3 5 6 10
 */
public class ExchangeCoins {

	static int N;
	static int[] coins;
	static int[] D;
	static int ex;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		coins = new int[N];
		for (int n = 0; n < N; ++n) {
			coins[n] = sc.nextInt();
		}
		ex = sc.nextInt();
		D = new int[ex + 1];

		for (int i = 0; i < N; ++i) {
			D[coins[i]] = 1;
		}

		for (int i = 1; i <= ex; ++i) {
			if (D[i] != 1) {
				D[i] = 123456789;
			}
		}
		for (int i = 1; i <= ex; ++i) {
			if (D[i] == 1) {
				continue;
			}
			int min = 123456789;
			for (int j = 0; j < N; ++j) {
				if (i - coins[j] > 0) {
					min = min(min, D[i - coins[j]] + 1);
				}
			}
			D[i] = min;
		}
		System.out.println(D[ex]);
	}

	public static int min(int a, int b) {
		if (a < b) {
			return a;
		} else {
			return b;
		}
	}
}
