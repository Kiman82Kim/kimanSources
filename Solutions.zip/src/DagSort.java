import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class DagSort {
	static int V;
	static int E;
	static int[] indegree;
	static ArrayList<Integer>[] P;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		V = Integer.parseInt(st.nextToken());
		E = Integer.parseInt(st.nextToken());
		indegree = new int[V + 1];
		P = new ArrayList[V + 1];
		for (int i = 0; i <= V; ++i) {
			P[i] = new ArrayList<Integer>();
		}
		for (int e = 0; e < E; ++e) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int x = Integer.parseInt(st.nextToken());
			int y = Integer.parseInt(st.nextToken());
			P[x].add(y);
			++indegree[y];
		}
		ArrayList<Integer> order = new ArrayList<Integer>();
		Queue<Integer> q = new LinkedList<Integer>();
		for (int i = 1; i <= V; ++i) {
			if (indegree[i] == 0) {
				q.add(i);
			}
		}
		while (!q.isEmpty()) {
			int now = q.poll();
			order.add(now);
			for (int next : P[now]) {
				--indegree[next];
				if (indegree[next] == 0) {
					q.add(next);
				}
			}
		}
		for (int o : order) {
			bw.append(o + " ");
		}
		bw.flush();
		bw.close();
	}

}
