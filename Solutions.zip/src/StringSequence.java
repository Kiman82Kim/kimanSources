import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringSequence {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String s1 = br.readLine().trim();
		String s2 = br.readLine().trim();
		String s3 = br.readLine().trim();
		int len = s1.length();
		char[] SM = new char[len];
		for (int i = 0; i < len; ++i) {
			if (s1.charAt(i) == s2.charAt(i)) {
				if (s1.charAt(i) == s3.charAt(i)) {
					SM[i] = s1.charAt(i);
				}
			}
		}

	}

}
