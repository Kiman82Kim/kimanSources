import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class GhostShip {

	static class Node {
		int x;
		int y;
		int status;
	}

	static int W;
	static int H;
	static String S;
	static int[][] P;
	static int[][] D;
	static int[] dx = { 1, 0, -1, 0 };
	static int[] dy = { 0, -1, 0, 1 };

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		W = sc.nextInt();
		H = sc.nextInt();

		P = new int[H + 1][W + 1];
		D = new int[H + 1][W + 1];
		int sX = 0;
		int sY = 0;
		int eX = 0;
		int eY = 0;
		for (int h = 1; h <= H; ++h) {
			S = sc.next();
			for (int i = 1; i <= W; ++i) {
				char c = S.charAt(i - 1);
				if (c == 'X') {
					P[h][i] = 0;
				}
				if (c == 'O') {
					P[h][i] = 1;
				}
				if (c == 'S') {
					P[h][i] = 2;
					sX = i;
					sY = h;

				}
				if (c == 'E') {
					P[h][i] = 3;
					eX = i;
					eY = h;
				}
			}
		}
		Queue<Node> q = new LinkedList<Node>();
		Node node = new Node();
		int step = 1;
		//		for (int i = 0; i <= H; ++i) {
		//			for (int j = 0; j <= W; ++j) {
		//				D[i][j] = 3000000;
		//			}
		//		}
		node.x = sX;
		node.y = sY;
		q.add(node);
		D[sY][sX] = 0;
		while (!q.isEmpty()) {
			Node n = q.poll();
			++step;
			for (int d = 0; d < 4; ++d) {
				if (n.y + dy[d] > 0 && n.x + dx[d] > 0 && n.y + dy[d] <= H && n.x + dx[d] <= W) {
					if (P[n.y + dy[d]][n.x + dx[d]] == 1
							&& (D[n.y + dy[d]][n.x + dx[d]] == 0 || D[n.y][n.x] + 1 < D[n.y + dy[d]][n.x + dx[d]])) {
						Node nn = new Node();
						nn.x = n.x + dx[d];
						nn.y = n.y + dy[d];
						q.add(nn);
						D[n.y + dy[d]][n.x + dx[d]] = D[n.y][n.x] + 1;
					}
					if (P[n.y + dy[d]][n.x + dx[d]] == 3
							&& (D[n.y + dy[d]][n.x + dx[d]] == 0 || D[n.y][n.x] + 1 < D[n.y + dy[d]][n.x + dx[d]])) {
						D[n.y + dy[d]][n.x + dx[d]] = D[n.y][n.x] + 1;
						break;
					}
				}
			}
		}
		if (D[eY][eX] == 0) {
			D[eY][eX] = -1;
		}
		System.out.println(D[eY][eX]);
	}

}
