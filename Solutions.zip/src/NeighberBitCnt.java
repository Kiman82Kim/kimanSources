import java.util.Scanner;

public class NeighberBitCnt {

	static int N;
	static int K;
	static int[][][] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for (int t = 1; t <= T; ++t) {
			int temp = sc.nextInt();
			N = sc.nextInt();
			K = sc.nextInt();

			D = new int[2][N + 1][K + 1];
			D[0][2][0] = 2;
			D[1][2][0] = 1;
			D[1][2][1] = 1;

			// for (int i = 1; i <= N; ++i) {
			// D[1][i][0] = 1;
			// D[0][i][0] = 1;
			// }
			for (int i = 3; i <= N; ++i) {
				for (int k = 0; k <= K; ++k) {
					D[0][i][k] = D[0][i - 1][k] + D[1][i - 1][k];
					if (k == 0) {
						D[1][i][k] = D[0][i - 1][k];
					} else {
						D[1][i][k] = D[1][i - 1][k - 1] + D[0][i - 1][k];
					}
				}
			}
			int sum = D[0][N][K] + D[1][N][K];
			System.out.println(t + " " + sum);
			// 1 1 5 2
		}
	}

}
