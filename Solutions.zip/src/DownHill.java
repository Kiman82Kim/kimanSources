import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class DownHill {

	static int N;
	static int M;
	static int[][] D;
	static int[][] P;
	static int[] dx = { 1, 0, -1, 0 };
	static int[] dy = { 0, 1, 0, -1 };
	static boolean[][] visit;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		M = Integer.parseInt(st.nextToken());
		D = new int[N + 1][M + 1];
		P = new int[N + 1][M + 1];

		for (int i = 0; i <= N; ++i) {
			P[i][0] = Integer.MAX_VALUE;
		}
		for (int i = 0; i <= M; ++i) {
			P[0][i] = Integer.MAX_VALUE;
		}
		for (int n = 1; n <= N; ++n) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			for (int m = 1; m <= M; ++m) {
				P[n][m] = Integer.parseInt(st.nextToken());
			}
		}

		visit = new boolean[N + 1][M + 1];

		D[1][1] = 1;
		visit[1][1] = true;
		int sum = dp(N, M);
		System.out.println(sum);
	}

	static int dp(int y, int x) {
		if (visit[y][x]) {
			return D[y][x];
		}
		visit[y][x] = true;
		int sum = 0;
		for (int d = 0; d < 4; ++d) {
			int nx = x + dx[d];
			int ny = y + dy[d];
			if (nx != -1 && ny != -1 && nx <= M && ny <= N) {
				if (P[ny][nx] > P[y][x]) {
					sum = (sum + dp(ny, nx)) % 1234567;
				}
			}
		}
		D[y][x] = sum;
		return sum;
	}
}
