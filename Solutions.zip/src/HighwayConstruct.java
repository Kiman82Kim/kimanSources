import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class HighwayConstruct {
	static class myCompare implements Comparator<Edge> {

		@Override
		public int compare(Edge e1, Edge e2) {
			// TODO Auto-generated method stub
			if (e1.cost > e2.cost) {
				return 1;
			} else {
				return -1;
			}
		}

	}

	static int N;
	static int M;
	static ArrayList<Edge>[] Road;
	static int[] D;

	static class Edge {
		int from;
		int to;
		int cost;
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());
		M = Integer.parseInt(br.readLine().trim());
		Road = new ArrayList[N + 1];
		for (int i = 0; i <= N; ++i) {
			Road[i] = new ArrayList<Edge>();
		}
		D = new int[N + 1];
		for (int i = 2; i <= N; ++i) {
			D[i] = 100000;
		}
		for (int m = 0; m < M; ++m) {
			String str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			int x = Integer.parseInt(st.nextToken());
			int y = Integer.parseInt(st.nextToken());
			int cost = Integer.parseInt(st.nextToken());
			Edge n = new Edge();
			n.from = x;
			n.to = y;
			n.cost = cost;
			Road[x].add(n);
			Edge n2 = new Edge();
			n2.from = y;
			n2.to = x;
			n2.cost = cost;
			Road[y].add(n2);
		}

		PriorityQueue<Edge> q = new PriorityQueue<Edge>(N, new myCompare());

		int from = 1;
		//		q.add(from);
		int cost = 0;
		Edge te = new Edge();
		te.from = 0;
		te.to = 1;
		te.cost = 0;
		q.add(te);
		boolean[] visit = new boolean[N + 1];
		visit[1] = true;
		long sum = 0;
		while (!q.isEmpty()) {
			Edge e = q.poll();
			if (D[e.to] < e.cost) {
				continue;
			}
			D[e.to] = e.cost;
			visit[e.to] = true;
			for (Edge node : Road[e.to]) {
				if (!visit[node.to]) {
					q.add(node);
				}
			}
		}
		for (int c : D) {
			sum += c;
		}
		System.out.println(sum);
	}

}
