import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class PointOfDot {
	static int N;
	static int[][] P;
	static int[] X;
	static int[] Y;
	static int maxPoint = 1000000001;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		N = Integer.parseInt(br.readLine().trim());
		P = new int[2][2];
		X = new int[N];
		Y = new int[N];

		for (int n = 0; n < N; ++n) {
			String str = br.readLine().trim();
			StringTokenizer st = new StringTokenizer(str);
			X[n] = Integer.parseInt(st.nextToken());
			Y[n] = Integer.parseInt(st.nextToken());
		}
		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		P[0][0] = Integer.parseInt(st.nextToken());
		P[0][1] = Integer.parseInt(st.nextToken());
		str = br.readLine().trim();
		st = new StringTokenizer(str);
		P[1][0] = Integer.parseInt(st.nextToken());
		P[1][1] = Integer.parseInt(st.nextToken());
		for (int k = 0; k < 2; ++k) {
			int crossCnt = 0;
			for (int i = 0; i < N; ++i) {
				int px = P[k][0];
				int py = P[k][1];
				int ptx = maxPoint;
				int pty = py + 1;
				int j = i + 1;
				if (i == N - 1) {
					j = 0;
				}
				if (isCross(X[i], Y[i], X[j], Y[j], px, py, ptx, pty)) {
					++crossCnt;
				}
			}
			if ((crossCnt & 1) == 1) {
				System.out.println("in");
			} else {
				System.out.println("out");
			}

		}
	}

	public static int ccw(int x1, int y1, int x2, int y2, int x3, int y3) {
		long c = (long) (x2 - x1) * (y3 - y1) - (long) (x3 - x1) * (y2 - y1);
		if (c > 0) {
			// �ݽð�
			return 1;
		} else if (c < 0) {
			// �ð�
			return -1;
		} else {
			return 0;
		}
	}

	public static boolean isCross(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4) {
		if (ccw(x1, y1, x2, y2, x3, y3) * ccw(x1, y1, x2, y2, x4, y4) == -1
				&& ccw(x3, y3, x4, y4, x1, y1) * ccw(x3, y3, x4, y4, x2, y2) == -1) {
			return true;
		} else {
			return false;
		}
	}
	// ab�� cd�� �����Ѵ�.
	// ccw(a,b,c)*ccw(a,b,d) = -1 and ccw(c,d,a)*ccw(c,d,b) = -1
	// ccw(a,b,c) �ǹ� : ab ���п��� c �� ���� �ٶ� ��, �ݽð� �����̸� ���.
	//(x_2 - x_1)(y_3-y_1) - (y_2-y_1)(x_3-x_1)
}
