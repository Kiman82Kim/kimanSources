import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class DivIncreseSubsquence {

	static class Node {
		int idx;
		int v;

		public Node(int idx, int v) {
			this.idx = idx;
			this.v = v;
		}

	}

	static int N;
	static int[] D;
	static int SubCnt;
	static ArrayList<Node>[] A;

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);

		N = Integer.parseInt(st.nextToken());
		str = br.readLine().trim();
		st = new StringTokenizer(str);
		A = new ArrayList[N];
		SubCnt = 0;

		for (int n = 0; n < N; ++n) {
			A[n] = new ArrayList<Node>();
			int num = Integer.parseInt(st.nextToken());
			if (n == 0) {
				A[0].add(new Node(1, num));
				++SubCnt;
				continue;
			}
			int idx = bi(num);
			if (A[idx].size() == 0) {
				++SubCnt;
			}
			A[idx].add(new Node(n + 1, num));
		}
		System.out.println(SubCnt);
		for (int i = 0; i < N && A[i].size() != 0; ++i) {
			bw.write("" + A[i].size());
			for (Node n : A[i]) {
				bw.append(" ").append("" + n.idx);
			}
			bw.append("\n");
		}
		bw.flush();
		bw.close();
	}

	public static int bi(int num) {
		int s = 0;
		int e = SubCnt - 1;

		while (s <= e) {
			if (e - s <= 2) {
				for (int i = s; i <= e; ++i) {
					int lastNum = A[i].get(A[i].size() - 1).v;
					if (lastNum < num) {
						return i;
					}
				}
				return e + 1;
			}
			int mid = (s + e) / 2;
			int lastNum = A[mid].get(A[mid].size() - 1).v;
			if (lastNum > num) {
				int nextLastNum = A[mid + 1].get(A[mid + 1].size() - 1).v;
				if (nextLastNum < num) {
					return mid + 1;
				}
				s = mid + 1;
			} else if (lastNum < num) {
				int pastLastNum = A[mid - 1].get(A[mid - 1].size() - 1).v;
				if (pastLastNum > num) {
					return mid;
				}
				e = mid - 1;
			} else if (lastNum == num) {
				if (A[mid + 1].size() == 0) {
					return mid + 1;
				} else {
					s = mid + 1;
				}
			}
		}
		return -1;
	}
}
/*
10
5 4 3 2 1 7 3 9 5 10

10
5 4 3 2 1 5 4 3 2 1

8
3 4 1 9 4 2 7 5

18
3 4 1 9 4 2 7 5 1 3 4 1 9 4 2 7 5 1

5
5 4 3 2 1
 */
