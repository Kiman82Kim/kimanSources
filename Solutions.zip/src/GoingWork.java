import java.util.Scanner;

public class GoingWork {

	static int H;
	static int W;
	static int N;
	static boolean[][] B;
	static int[][] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		H = sc.nextInt();
		W = sc.nextInt();
		N = sc.nextInt();

		D = new int[H + 1][W + 1];
		B = new boolean[H + 1][W + 1];
		for (int i = 0; i < H; ++i) {
			for (int j = 0; j < W; ++j) {
				int t = sc.nextInt();
				if (t == 0) {
					B[i][j] = false;
				} else {
					B[i][j] = true;
				}
			}
		}
		D[0][0] = N - 1;
		for (int i = 0; i < H; ++i) {
			for (int j = 0; j < W; ++j) {
				if (B[i][j]) {
					if ((D[i][j] & 1) == 1) {
						D[i][j + 1] = D[i][j] / 2 + 1;
						D[i + 1][j] = D[i][j] / 2;
					} else {
						D[i][j + 1] = D[i][j] / 2;
						D[i + 1][j] = D[i][j] / 2 + 1;
					}
				} else {
					if ((D[i][j] & 1) == 1) {
						D[i][j + 1] = D[i][j] / 2;
						D[i + 1][j] = D[i][j] / 2 + 1;
					} else {
						D[i][j + 1] = D[i][j] / 2 + 1;
						D[i + 1][j] = D[i][j] / 2;
					}
				}
			}
		}
		for (int i = 0; i < H; ++i) {
			for (int j = 0; j < W; ++j) {
				if ((D[i][j] & 1) == 1) {
					B[i][j] = !B[i][j];
				}
			}
		}
		int x = 0;
		int y = 0;
		for (int i = 0; i <= H; ++i) {
			if (B[y][x]) {
				++x;
			} else {
				++y;
			}
			if (x > W || y > H) {
				break;
			}
		}
		System.out.println((y + 1) + " " + (x + 1));
	}

}
