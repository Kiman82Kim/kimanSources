import java.util.Scanner;

public class PaperRecycle {

	static int N;
	static int[][] C;
	static int[][] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		C = new int[N + 1][N + 1];
		D = new int[N + 1][N + 1];
		for (int n = 1; n <= N; ++n) {
			for (int nn = 1; nn <= N; ++nn) {
				C[n][nn] = sc.nextInt();
			}
		}
		for (int i = 1; i <= N; ++i) {
			for (int j = 1; j <= N; ++j) {
				if (i == 1 && j == 1) {
					D[i][j] = C[1][1];
				}
				if (i > 1) {
					if (D[i - 1][j] + C[i][j] > D[i][j]) {
						D[i][j] = D[i - 1][j] + C[i][j];
					}
				}
				if (j > 1) {
					if (D[i][j - 1] + C[i][j] > D[i][j]) {
						D[i][j] = D[i][j - 1] + C[i][j];
					}
				}
			}
		}
		// go(0, 0, 0);
		System.out.println(D[N][N]);
	}

	public static void go(int x, int y, int c) {
		if (D[x][y] == 0) {
			D[x][y] = C[x][y] + c;
		} else {
			if (C[x][y] + c > D[x][y]) {
				D[x][y] = C[x][y] + c;
			} else {
				return;
			}
		}
		if (x + 1 < N) {
			go(x + 1, y, C[x][y] + c);
		}
		if (y + 1 < N) {
			go(x, y + 1, C[x][y] + c);
		}
	}
}
