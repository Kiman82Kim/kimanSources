import java.util.ArrayList;
import java.util.Scanner;

public class PrimeMulti {

	static int K;
	static int N;
	static int[] PL;
	static int[] Cnt;
	static ArrayList<Integer> Narr;
	static int[] MultiNum;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		K = sc.nextInt();
		N = sc.nextInt();

		PL = new int[K + 1];
		Cnt = new int[K + 1];
		MultiNum = new int[K + 1];
		Narr = new ArrayList<Integer>();
		Narr.add(1);

		for (int k = 1; k <= K; ++k) {
			PL[k] = sc.nextInt();
			Cnt[k] = 1;
			MultiNum[k] = PL[k];
		}

		for (int i = 1; i <= N; ++i) {
			int min = Integer.MAX_VALUE;
			for (int j = 1; j <= K; ++j) {
				if (MultiNum[j] < min) {
					min = MultiNum[j];
				}
			}
			Narr.add(min);
			for (int j = 1; j <= K; ++j) {
				if (MultiNum[j] == min) {
					++Cnt[j];
					MultiNum[j] = PL[j] * Narr.get(Cnt[j] - 1);
				}
			}
		}
		System.out.println(Narr.get(Narr.size() - 1));
	}

}
