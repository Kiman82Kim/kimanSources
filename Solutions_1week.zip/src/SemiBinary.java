import java.util.Scanner;

public class SemiBinary {

	static int N;
	static long[] D0;
	static long[] D1;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		D0 = new long[N + 1];
		D1 = new long[N + 1];
		D1[1] = 1;
		if (N > 1) {
			D0[2] = 1;
		}

		// D0[1] = -1;
		// D1[2] = -1;
		for (int i = 3; i <= N; ++i) {

			D0[i] = D0[i - 1] + D1[i - 1];
			D1[i] = D0[i - 1];
		}
		System.out.println(D0[N] + D1[N]);
	}

}
