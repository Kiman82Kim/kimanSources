import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class MaxSubSum {

	static int N;
	static int[] AN;
	static long[] D;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		// Scanner sc = new Scanner(System.in);
		// N = sc.nextInt();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine();
		N = Integer.parseInt(str);
		AN = new int[N + 1];
		D = new long[N + 1];
		StringTokenizer st = new StringTokenizer(br.readLine());
		long max = Integer.MIN_VALUE;
		for (int i = 1; i <= N; ++i) {
			// int num = sc.nextInt();
			AN[i] = Integer.parseInt(st.nextToken());
			long sum = D[i - 1] + AN[i];
			if (sum < 0) {
				D[i] = AN[i];
			} else {
				if (AN[i] > sum) {
					D[i] = AN[i];
				} else {
					D[i] = sum;
				}
			}
			if (D[i] > max) {
				max = D[i];
			}
		}

		System.out.println(max);
	}
}
