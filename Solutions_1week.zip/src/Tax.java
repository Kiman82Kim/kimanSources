import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Tax {

	public static int N;
	public static int K;
	public static int[] M;
	public static long[] D;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);

		N = Integer.parseInt(st.nextToken());
		K = Integer.parseInt(st.nextToken());

		M = new int[N];
		D = new long[N];
		str = br.readLine().trim();
		st = new StringTokenizer(str);

		for (int n = 0; n < N; ++n) {
			M[n] = Integer.parseInt(st.nextToken());
			long sum = M[n];
			if (n != 0) {
				sum = D[n - 1] + M[n];
			}

			if (sum < 0) {
				D[n] = M[n];
			} else {
				if (M[n] > sum) {
					D[n] = M[n];
				} else {
					D[n] = sum;
				}
			}
		}
		Arrays.sort(D);
		System.out.println(D[K - 1]);
	}

}
