import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Midium {

	static int N;
	static int[] D;
	static PriorityQueue<Integer> Upq;
	static PriorityQueue<Integer> Dpq;
	static int Mid;

	static class myCompare implements Comparator<Integer> {

		@Override
		public int compare(Integer a, Integer b) {
			// TODO Auto-generated method stub
			if (a > b) {
				return -1;
			} else {
				return 1;
			}
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		Upq = new PriorityQueue<Integer>();
		Dpq = new PriorityQueue<Integer>(new myCompare());

		for (int n = 0; n < N; ++n) {
			int num = sc.nextInt();
			if (Dpq.isEmpty()) {
				Dpq.add(num);
			} else if (Upq.isEmpty()) {
				Upq.add(num);
			} else if (num >= Dpq.peek()) {
				Upq.add(num);
			} else {
				Dpq.add(num);
			}
			if (n % 2 == 1) {
				if (Upq.size() > Dpq.size()) {
					Dpq.add(Upq.poll());
				} else if (Upq.size() < Dpq.size()) {
					Upq.add(Dpq.poll());
				}
			}
			if (n % 2 == 0) {
				if (Upq.size() >= Dpq.size()) {
					Dpq.add(Upq.poll());
				}
				Mid = Dpq.peek();
				System.out.println(Mid);
			}
		}
	}

}
