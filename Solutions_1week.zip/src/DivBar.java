import java.util.Scanner;

public class DivBar {

	static int N;
	static int[] B;
	static int[] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		B = new int[N + 1];
		D = new int[N + 1];
		for (int n = 1; n <= N; ++n) {
			B[n] = sc.nextInt();
		}

		for (int i = 1; i <= N; ++i) {
			int max = 0;
			for (int j = 0; j <= i; ++j) {
				max = max(D[j] + B[i - j], max);
			}
			D[i] = max;
		}
		System.out.println(D[N]);
	}

	public static int max(int a, int b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
	}
}
