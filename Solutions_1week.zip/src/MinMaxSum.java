import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class MinMaxSum {
	static class NumProp {
		long sum;
		int min;
		int max;
	}

	static int N;
	static int M;
	static NumProp[] NP;
	static int Start;
	static int Depth;
	static int[] Num;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		String str = br.readLine().trim();
		N = Integer.parseInt(str);
		Num = new int[N];

		str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		for (int n = 0; n < N; ++n) {
			Num[n] = Integer.parseInt(st.nextToken());
		}
		Start = 1;
		while (Start < N) {
			Start <<= 1;
			++Depth;
		}

		int treeSize = (int) Math.pow(2, Depth + 1);
		NP = new NumProp[treeSize + 1];
		for (int i = 0; i <= treeSize; ++i) {
			NP[i] = new NumProp();
		}
		for (int i = 0; i < N; ++i) {
			NumProp np = new NumProp();
			np.sum = Num[i];
			np.min = Num[i];
			np.max = Num[i];

			NP[Start + i] = np;
		}

		init();

		str = br.readLine().trim();
		M = Integer.parseInt(str);
		for (int m = 0; m < M; ++m) {
			str = br.readLine().trim();
			st = new StringTokenizer(str);
			int from = Integer.parseInt(st.nextToken());
			int to = Integer.parseInt(st.nextToken());
			NumProp np = getProp(from, to);
			bw.write(np.min + " " + np.max + " " + np.sum + "\n");
		}
		bw.flush();
		bw.close();
	}

	public static void init() {
		int idx = (int) Math.pow(2, Depth) - 1;
		while (idx > 0) {
			NumProp np = new NumProp();
			np.sum = NP[idx * 2].sum + NP[idx * 2 + 1].sum;
			np.min = Math.min(NP[idx * 2].min == 0 ? Integer.MAX_VALUE : NP[idx * 2].min,
					NP[idx * 2 + 1].min == 0 ? Integer.MAX_VALUE : NP[idx * 2 + 1].min);
			np.max = Math.max(NP[idx * 2].max, NP[idx * 2 + 1].max);
			NP[idx] = np;
			--idx;
		}
	}

	public static NumProp getProp(int from, int to) {
		int min = Integer.MAX_VALUE;
		int max = 0;
		long sum = 0;
		from += Start - 1;
		to += Start - 1;
		NumProp np = new NumProp();
		while (to > from) {
			if ((from & 1) == 1) { // right
				min = Math.min(min, NP[from].min);
				max = Math.max(max, NP[from].max);
				sum += NP[from].sum;
				++from;
			}
			if ((to & 1) == 0) { // left
				min = Math.min(min, NP[to].min);
				max = Math.max(max, NP[to].max);
				sum += NP[to].sum;
				--to;
			}
			from >>= 1;
			to >>= 1;
		}
		if (to == from) {
			min = Math.min(min, NP[from].min);
			max = Math.max(max, NP[from].max);
			sum += NP[from].sum;
		}
		np.min = min;
		np.max = max;
		np.sum = sum;
		return np;
	}
}
