import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LineSched {

	static int N;
	static int e1;
	static int e2;
	static int x1;
	static int x2;
	static int[] s1;
	static int[] s2;
	static int[] t1;
	static int[] t2;
	static int[] a1;
	static int[] a2;

	static int L;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		// Scanner sc = new Scanner(System.in);
		//
		// N = sc.nextInt();
		// e1 = sc.nextInt();
		// e2 = sc.nextInt();
		// x1 = sc.nextInt();
		// x2 = sc.nextInt();
		// s1 = new int[N];
		// s2 = new int[N];
		// t1 = new int[N - 1];
		// t2 = new int[N - 1];
		// a1 = new int[N];
		// a2 = new int[N];
		// for (int n = 0; n < N; ++n) {
		// s1[n] = sc.nextInt();
		// }
		// for (int n = 0; n < N; ++n) {
		// s2[n] = sc.nextInt();
		// }
		// for (int n = 0; n < N - 1; ++n) {
		// t1[n] = sc.nextInt();
		// }
		// for (int n = 0; n < N - 1; ++n) {
		// t2[n] = sc.nextInt();
		// }

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine();
		String[] strArr = str.split(" ");
		N = Integer.parseInt(strArr[0]);
		e1 = Integer.parseInt(strArr[1]);
		e2 = Integer.parseInt(strArr[2]);
		x1 = Integer.parseInt(strArr[3]);
		x2 = Integer.parseInt(strArr[4]);

		s1 = new int[N];
		s2 = new int[N];
		t1 = new int[N - 1];
		t2 = new int[N - 1];
		a1 = new int[N];
		a2 = new int[N];

		str = br.readLine();
		strArr = str.split(" ");
		for (int n = 0; n < N; ++n) {
			s1[n] = Integer.parseInt(strArr[n]);
		}
		str = br.readLine();
		strArr = str.split(" ");
		for (int n = 0; n < N; ++n) {
			s2[n] = Integer.parseInt(strArr[n]);
		}
		str = br.readLine();
		strArr = str.split(" ");
		for (int n = 0; n < N - 1; ++n) {
			t1[n] = Integer.parseInt(strArr[n]);
		}
		str = br.readLine();
		strArr = str.split(" ");
		for (int n = 0; n < N - 1; ++n) {
			t2[n] = Integer.parseInt(strArr[n]);
		}

		a1[0] = e1 + s1[0];
		a2[0] = e2 + s2[0];
		for (int i = 1; i < N; ++i) {
			a1[i] = min(a1[i - 1] + s1[i], a2[i - 1] + t2[i - 1] + s1[i]);
			a2[i] = min(a2[i - 1] + s2[i], a1[i - 1] + t1[i - 1] + s2[i]);
		}
		int min = min(a1[N - 1] + x1, a2[N - 1] + x2);
		System.out.println(min);
	}

	public static int max(int a, int b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
	}

	public static int min(int a, int b) {
		if (a < b) {
			return a;
		} else {
			return b;
		}
	}
}
