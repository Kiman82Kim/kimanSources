import java.util.Scanner;

public class StoneBridge {

	static String M;
	static String[] S;
	static int[][][] D;
	static int ti;
	static int si;

	/*
	D[i][j][0] : õ��� ������ i��° M ���ڿ����� j��° ���ٸ� ���� �̿�.
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		M = sc.next();
		S = new String[2];
		S[0] = sc.next();
		S[1] = sc.next();
		ti = M.length();
		si = S[0].length();
		D = new int[ti + 1][si + 1][2];
		D[0][0][0] = 1;
		D[0][0][1] = 1;
		for (int i = 1; i <= ti; ++i) {
			for (int j = 1; j <= si; ++j) {
				if (M.charAt(i - 1) == S[0].charAt(j - 1)) {
					for (int k = 0; k < j; ++k) {
						D[i][j][0] += D[i - 1][k][1];
					}
				}
				if (M.charAt(i - 1) == S[1].charAt(j - 1)) {
					for (int k = 0; k < j; ++k) {
						D[i][j][1] += D[i - 1][k][0];
					}
				}
			}
		}
		int sum = 0;
		for (int j = 1; j <= si; ++j) {
			sum += D[ti][j][0] + D[ti][j][1];
		}
		System.out.println(sum);
	}

	/*
	 RGS
	RINGSR
	GRGGNS
	 */
}
