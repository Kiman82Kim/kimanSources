import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Cave {
	static int N;
	static int H;
	static int[] U;
	static int[] B;

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str = br.readLine();
		StringTokenizer st = new StringTokenizer(str);
		N = Integer.parseInt(st.nextToken());
		H = Integer.parseInt(st.nextToken());

		int be = N / 2;
		if (N % 2 == 1) {
			be = N / 2 + 1;
		}
		B = new int[be];
		U = new int[N / 2];

		for (int i = 0; i < N / 2; ++i) {
			B[i] = Integer.parseInt(br.readLine());
			U[i] = Integer.parseInt(br.readLine());
		}
		if (N % 2 == 1) {
			B[N / 2] = Integer.parseInt(br.readLine());
		}

		Arrays.sort(B);
		Arrays.sort(U);

		int flyH = 1;
		int sum = 0;
		int cnt = 0;
		int min = Integer.MAX_VALUE;
		int bi = 0;
		int ui = 0;
		for (flyH = 1; flyH <= H; ++flyH) {
			int b = 0;
			int u = 0;

			for (int i = bi; i < be; ++i) {
				if (B[i] >= flyH) {
					b = be - i;
					bi = i;
					break;
				}
			}
			int ue = N / 2 - ui;
			for (int i = 0; i < ue; ++i) {
				if (U[i] > H - flyH) {
					u = N / 2 - i;
					ui = u;
					break;
				}
			}
			if (ue == 0) {
				u = N / 2;
			}
			sum = b + u;
			if (sum < min) {
				min = sum;
				cnt = 1;
			} else if (sum == min) {
				++cnt;
			}
		}
		System.out.println(min + " " + cnt);
	}

}
