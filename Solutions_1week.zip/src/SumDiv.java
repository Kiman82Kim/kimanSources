import java.util.Scanner;

public class SumDiv {

	static int N;
	static int K;
	static long[][] D;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		N = sc.nextInt();
		K = sc.nextInt();

		D = new long[N + 1][K + 1];

		D[N][K] = sumDiv(N, K) % 1000000000;
		System.out.println(D[N][K]);
	}

	public static long sumDiv(int n, int k) {
		if (k == 1) {
			return 1;
		}
		if (D[n][k] != 0) {
			return D[n][k];
		}
		long sum = 0;
		for (int i = 1; i <= n + 1; ++i) {
			D[i - 1][k - 1] = sumDiv(i - 1, k - 1) % 1000000000;
			sum += D[i - 1][k - 1] % 1000000000;
		}
		return sum % 1000000000;
	}
}
