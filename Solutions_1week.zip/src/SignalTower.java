import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Stack;
import java.util.StringTokenizer;

public class SignalTower {

	static int N;
	static int[] T;
	static Stack<P> S;
	static Stack<Integer> R;

	static class P {
		int h;
		int idx;

		public P(int h, int idx) {
			this.h = h;
			this.idx = idx;
		}
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		String str = br.readLine().trim();
		N = Integer.parseInt(str);
		T = new int[N + 1];
		str = br.readLine().trim();
		StringTokenizer st = new StringTokenizer(str);
		S = new Stack<P>();
		R = new Stack<Integer>();

		T[0] = Integer.MAX_VALUE;
		for (int n = 1; n <= N; ++n) {
			T[n] = Integer.parseInt(st.nextToken());
		}
		/*for (int i = N; i >= 0; --i) {
			while (!S.isEmpty()) {
				P p = S.peek();
				if (p.h <= T[i]) {
					S.pop();
					R.add(i);
				} else {
					break;
				}
			}
			S.push(new P(T[i], i));
		}
		System.out.print(R.lastElement());
		R.pop();
		while (!R.isEmpty()) {
		
			System.out.print(" " + R.pop());
		}
		System.out.println();*/

		StringBuffer sb = new StringBuffer();
		for (int i = 0; i <= N; ++i) {
			while (!S.isEmpty()) {
				P p = S.peek();
				if (p.h < T[i]) {
					S.pop();
				} else {
					sb.append(p.idx).append(" ");
					break;
				}
			}
			S.push(new P(T[i], i));
		}
		System.out.println(sb.toString().trim());
	}

}
