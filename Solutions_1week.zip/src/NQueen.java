import java.util.Scanner;

public class NQueen {
	static int N;
	static int[] P;
	static boolean[] U;
	static boolean[] X;
	static boolean[] Y;
	static int C;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		P = new int[N + 1];
		U = new boolean[N + 1];
		X = new boolean[2 * N + 1];
		Y = new boolean[2 * N + 1];

		C = 0;
		nQueen(1, 1);
		System.out.println(C);
	}

	public static void nQueen(int x, int num) {
		if (x > N) {
			++C;
			return;
		}
		for (int i = 1; i <= N; ++i) {
			if (!U[i] && !X[x + i] && !Y[i - x + N]) {
				U[i] = true;
				X[x + i] = true;
				Y[i - x + N] = true;
				P[x] = i;
				nQueen(x + 1, i);
				U[i] = false;
				X[x + i] = false;
				Y[i - x + N] = false;
				P[x] = 0;
			}
		}

	}
}
