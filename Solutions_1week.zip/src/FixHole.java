import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

public class FixHole {

	static int N;
	static int X;
	static int[] D;

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		X = Integer.parseInt(br.readLine());
		N = Integer.parseInt(br.readLine());
		D = new int[N];

		for (int i = 0; i < N; ++i) {
			D[i] = Integer.parseInt(br.readLine());
		}
		Arrays.sort(D);
		X *= 10000000;
		int s = 0;
		int e = N - 1;
		while (s < e) {
			if (D[e] >= X) {
				--e;
				continue;
			}

			if (D[s] + D[e] == X) {
				System.out.println("yes " + D[s] + " " + D[e]);
				return;
			} else {
				if (D[s] + D[e] < X) {
					++s;
				}
				if (D[s] + D[e] > X) {
					--e;
				}
			}
		}
		System.out.println("danger");
	}
	/*
	1
	4
	9999996
	1
	2
	9999997
	 */
}
